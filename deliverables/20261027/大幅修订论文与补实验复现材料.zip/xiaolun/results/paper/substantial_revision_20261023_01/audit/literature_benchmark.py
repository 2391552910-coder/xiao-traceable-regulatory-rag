"""Read-only local PDF and DOCX inventory; approximate text amounts, verified captions."""
from pathlib import Path
from pypdf import PdfReader
from xml.etree import ElementTree as ET
import csv, hashlib, json, re, zipfile

ROOT=Path(__file__).resolve().parents[4];OUT=Path(__file__).resolve().parent
OLD=ROOT/'results/paper/journal_revision_20261023_01'
meta=json.loads((OLD/'literature_manifest.json').read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
counts={'KBS01':(6,6,'本文第1–6图、第1–6表；作者公开版，非期刊定稿'),
        'KBS02':(2,7,'第1–2图、第1–7表；综述，不作为实验论文篇幅标杆'),
        'INS01':(0,11,'未见编号图，第1–11表；出版社21页版；含算法和附录缩略语表'),
        'NEU02':(10,6,'第1–10图、第1–6表；第6表在附录；作者公开版，非期刊定稿')}
rows=[]
for r in meta['papers']:
    if not r.get('file'):continue
    p=OLD/'literature'/r['file'];reader=PdfReader(p)
    pages=[page.extract_text() or '' for page in reader.pages];text='\n'.join(pages)
    # References can begin in a column, so main-text amounts are approximate.
    refs=re.search(r'(?m)^[ \t]*(?:\d+\.[ \t]*)?References[ \t]*\r?$',text)
    main=text[:refs.start()] if refs else text
    # English PDF whitespace tokenization undercounts merged words and cannot be
    # compared one-for-one to Chinese characters; expose both measurements.
    fig,tab,note=counts[r['id']]
    rows.append(dict(id=r['id'],journal=r['journal'],title=r['title'],pages=len(reader.pages),
        numbered_figures_verified=fig,numbered_tables_verified=tab,
        extracted_approx_whitespace_words_total=len(text.split()),
        extracted_approx_whitespace_words_before_references=len(main.split()),
        nonspace_characters_total=len(re.sub(r'\s','',text)),
        nonspace_characters_before_references=len(re.sub(r'\s','',main)),
        version_note=note,doi=r['doi'],file=str(p.resolve()),sha256=sha(p)))
    (OUT/(p.stem+'_plain_extract.txt')).write_text(text,encoding='utf-8')
ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
docs=[]
sources=[ROOT/'results/paper/draft_20261023_01/年报与法规双源RAG小论文_双人评分结果修订稿.docx',
         OLD/'年报与法规双源RAG_期刊结构修订稿.docx']
for p in sources:
    with zipfile.ZipFile(p) as z:
        root=ET.fromstring(z.read('word/document.xml'));text='\n'.join(''.join(x.itertext()) for x in root.findall('.//w:t',ns))
        docs.append(dict(file=str(p.resolve()),sha256=sha(p),paragraphs=len(root.findall('.//w:p',ns)),
            tables=len(root.findall('.//w:tbl',ns)),drawings=len(root.findall('.//w:drawing',ns)),
            image_files=len([n for n in z.namelist() if n.startswith('word/media/')]),
            chinese_characters=len(re.findall(r'[\u4e00-\u9fff]',text)),
            nonspace_characters=len(re.sub(r'\s','',text)),latin_word_fragments=len(re.findall(r'[A-Za-z]+',text))))
result=dict(pdf_measurements=rows,existing_manuscript_measurements=docs,
    measurement_note='Figure/table counts inspected from numbered captions; appendix tables included and noted. Text amounts are extraction estimates, not journal requirements. English whitespace words and Chinese characters are not directly commensurable.',
    primary_template='INS01',
    structural_benchmark=['Introduction and explicit contribution scope','Background and related work with comparison table','Methodology with notation and algorithms','Data/tasks, evaluation protocol, metrics, baselines/configurations','Main results and component contrasts','Error analysis and threats to validity','Cost and latency','Discussion including negative findings and deployment choices','Limitations, conclusions, reproducibility details'],
    journal_quality_constraint='There is no verified universal journal page, word, figure or table minimum; increasing quantities alone cannot certify acceptance or CAS classification-level quality.')
(OUT/'literature_benchmark.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
with (OUT/'literature_benchmark.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
for r in rows:print(r['id'],r['pages'],r['numbered_figures_verified'],r['numbered_tables_verified'],r['extracted_approx_whitespace_words_total'],r['extracted_approx_whitespace_words_before_references'])
print(json.dumps(docs,ensure_ascii=False,indent=2))
