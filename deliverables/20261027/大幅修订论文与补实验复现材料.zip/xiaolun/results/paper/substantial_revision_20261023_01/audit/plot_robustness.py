"""Plot only verified audit statistics, with explicit observed/missing scope."""
from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
OUT=Path(__file__).resolve().parent
r=json.loads((OUT/'robustness_audit.json').read_text(encoding='utf-8'))
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,
                     'axes.spines.right':False,'savefig.dpi':320,'pdf.fonttype':42,'svg.fonttype':'none'})
names=['G2-G1','G3-G2','G3-G1','G3-NoRerank','G3-BM25']
colors=['#1b6a83','#a74c32','#1b6a83','#a74c32','#a74c32']
fig,ax=plt.subplots(figsize=(8.2,4.5))
for i,name in enumerate(names):
    x=r['contrasts'][name]['mean'];v=x['observed_pair_company_macro'];ci=x['cluster_ci95_20000'];lo=x['loco_range']
    # Bounds target question-average (same estimand as sample mean only with
    # balanced complete data); keep separate annotations and legend wording.
    b=x['full_question_average_bounds_using_available_counterparts']
    ax.plot(b,[i+.14,i+.14],color='#b2b2b2',lw=5,solid_capstyle='butt')
    ax.plot(ci,[i-.10,i-.10],color=colors[i],lw=2)
    ax.plot(lo,[i-.10,i-.10],color=colors[i],lw=7,alpha=.30)
    ax.scatter([v],[i-.10],color=colors[i],s=32,zorder=3)
    ax.text(1.03,i,f"{x['observed_pairs']}/60 pairs",transform=ax.get_yaxis_transform(),va='center',fontsize=9)
ax.axvline(0,color='#444444',lw=.9,ls='--');ax.set_yticks(range(len(names)),[n.replace('-',' − ') for n in names]);ax.invert_yaxis()
ax.set_xlabel('Difference in answer quality (0–8)');ax.set_xlim(-.55,.60);ax.grid(axis='x',alpha=.2)
ax.legend(handles=[Line2D([0],[0],color='#1b6a83',marker='o',lw=2,label='Observed company macro + 95% cluster interval'),Line2D([0],[0],color='#1b6a83',alpha=.3,lw=7,label='Leave-one-company-out range'),Line2D([0],[0],color='#b2b2b2',lw=5,label='Full 60-question mean: missing-score bounds')],loc='lower left',bbox_to_anchor=(-.01,-.40),frameon=False,fontsize=8.8)
fig.subplots_adjust(left=.20,right=.82,top=.98,bottom=.29)
for ext in ['png','svg']:fig.savefig(OUT/('missingness_and_loco_sensitivity.'+ext),bbox_inches='tight')
plt.close(fig)
fig,ax=plt.subplots(figsize=(8.2,4.4))
views=[('Observed pairwise',r['contrasts']),('49 common questions',r['question_complete_case']['five_main_and_retrieval']['contrasts']),('12 complete companies',r['whole_company_complete_case']['five_main_and_retrieval']['contrasts'])]
for j,(label,view) in enumerate(views):
    vals=[view[n]['mean']['observed_pair_company_macro'] if 'mean' in view[n] else view[n]['observed_pair_company_macro'] for n in names]
    ax.scatter([i+(j-1)*.16 for i in range(len(names))],vals,label=label,s=48,marker=['o','s','^'][j],color=['#176580','#b56a37','#668048'][j])
ax.axhline(0,color='#444444',lw=.9,ls='--');ax.set_xticks(range(len(names)),[n.replace('-',' − ') for n in names],rotation=15)
ax.set_ylabel('Observed company macro difference (0–8)');ax.set_ylim(-.48,.36);ax.grid(axis='y',alpha=.2)
ax.legend(frameon=False,loc='lower left',fontsize=9)
fig.tight_layout()
for ext in ['png','svg']:fig.savefig(OUT/('complete_case_sensitivity.'+ext),bbox_inches='tight')
plt.close(fig)
print('Rendered 2 sensitivity figures as PNG and SVG from saved audit JSON.')
