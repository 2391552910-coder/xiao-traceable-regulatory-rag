"""Post hoc quality diagnostics from accepted human reviews and saved calls.

No new API calls, new human labels, or semantic-support judgments are generated.
Run using the bundled Python. All source units and accepted reviews are hashed.
"""
from pathlib import Path
from collections import Counter, defaultdict
import csv
import hashlib
import json
import sys
from datetime import datetime, timezone

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from scripts.score_minimal_paper_reviews import validate_submission, FIELDS
from src.metrics.compact_paper_statistics import quadratic_kappa

OUT = ROOT / 'results/paper/substantial_revision_20261023_01/quality'
OLD = ROOT / 'results/runs/two_reviewer_statistics_windows_20261023_01'
MAP = ROOT / 'results/runs/paper_actual_output_review_windows_20261021_01/coordinator_private_mapping.json'
FREEZE = ROOT / 'results/runs/paper_execution_freeze_windows_20261020_01/execution_freeze.json'
INTAKE = ROOT / 'results/CURRENT_OUTPUT_REVIEW_INTAKE.json'
LABELS = {'merged_corpus_generic_cited_rag':'G1', 'dual_source_generic_cited_rag':'G2',
          'dual_source_role_grounded_rag':'G3', 'no_rerank':'No rerank', 'bm25_only':'BM25',
          'minus_annual':'No annual', 'minus_regulation':'No regulation',
          'k28__merged_corpus_generic_cited_rag':'K2.8 G1',
          'k28__dual_source_generic_cited_rag':'K2.8 G2',
          'k28__dual_source_role_grounded_rag':'K2.8 G3'}
MAIN = list(LABELS)[:5]
DIMLABELS = {'company_facts':'Company facts', 'regulation':'Regulation', 'citations':'Citation rubric',
             'uncertainty':'Uncertainty', 'total':'Total'}
DRAWS, SEED = 10000, 20261023

def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(name, value):
    (OUT/name).write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
def csvout(name, rows):
    if not rows: return
    keys=list(dict.fromkeys(k for r in rows for k in r))
    with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)

def paired(pairs, maximum):
    """Cluster bootstrap over equally weighted observed company means.

    Sharp full-inventory question-mean bounds retain any observed side of a pair.
    They allow missing scores anywhere in the rubric range; they are not imputations.
    """
    blocks=defaultdict(list);deltas=[];lo=hi=0.;counts=Counter()
    for q,c,a,b in pairs:
        if a is not None and b is not None:
            d=b-a;blocks[c].append(d);deltas.append(d);lo+=d;hi+=d;counts['both_known']+=1
        elif a is not None:
            lo-=a;hi+=maximum-a;counts['treatment_missing']+=1
        elif b is not None:
            lo+=b-maximum;hi+=b;counts['baseline_missing']+=1
        else:
            lo-=maximum;hi+=maximum;counts['both_missing']+=1
    vals=np.array([np.mean(x) for _,x in sorted(blocks.items())]);ci=None;loo=None
    if len(vals)>1:
        rng=np.random.default_rng(SEED)
        samples=vals[rng.integers(len(vals),size=(DRAWS,len(vals)))].mean(axis=1)
        ci=np.quantile(samples,[.025,.975]).tolist()
        l=(vals.sum()-vals)/(len(vals)-1);loo=[float(l.min()),float(l.max())]
    counts.update({k:0 for k in ['both_known','baseline_missing','treatment_missing','both_missing'] if k not in counts})
    return dict(planned=len(pairs),known=len(deltas),companies=len(vals),
        macro_delta=float(vals.mean()) if len(vals) else None,
        question_delta=float(np.mean(deltas)) if deltas else None,ci95=ci,
        full_inventory_question_mean_sharp_bounds=[lo/len(pairs),hi/len(pairs)],
        leave_one_company_out_range=loo,win=sum(v>0 for v in deltas),
        tie=sum(v==0 for v in deltas),loss=sum(v<0 for v in deltas),**counts)

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    if (OUT/'artifact_manifest.json').exists() and '--refresh-derived' not in sys.argv:
        raise ValueError('Preserve completed analysis; use --refresh-derived only for this reproducible derived run')
    mapping=read(MAP);freeze=read(FREEZE);intake=read(INTAKE)
    receipt=read(MAP.parent/'delivery_receipt.json')
    assert sha(MAP)==receipt['private_coordinator_mapping_sha256']
    expected={r['output_id']:r for r in mapping if r['status']=='completed'}
    reviews=[];inputs=[MAP,FREEZE,INTAKE,OLD/'per_output_scores.json',OLD/'statistics.json',Path(__file__)]
    for ref in intake['accepted_reviews']:
        p=Path(ref['file']);assert sha(p)==ref['sha256'];reviews.append(read(p));inputs.append(p)
    assert len(reviews)==2 and reviews[0]['reviewer_id']!=reviews[1]['reviewer_id']
    reviewer_scores=[validate_submission(r,expected) for r in reviews]
    grouping={r['question_id']:r for r in freeze['grouping']}
    scores=read(OLD/'per_output_scores.json');byqm={(r['question_id'],r['mode']):r for r in scores}
    assert len(scores)==len(expected)==386 and len(mapping)==400
    for r in scores:
        for i,rr in enumerate(reviewer_scores,1):
            assert all(r[f'R{i}'][f]==rr[r['output_id']][f] for f in FIELDS)
        assert all(r['mean'][f]==(r['R1'][f]+r['R2'][f])/2 for f in FIELDS)
        assert r['mean']['total']==sum(r['mean'][f] for f in FIELDS)
    source_manifest=[];units={};flat=[]
    for m in mapping:
        p=Path(m['source_file']);h=sha(p);assert h==m['source_sha256']
        d=read(p);units[m['output_id']]=d
        source_manifest.append(dict(output_id=m['output_id'],file=str(p),sha256=h,status=m['status']))
        z=d.get('raw_sdk_response') or {};u=z.get('usage') or {}
        if all(isinstance(u.get(k),int) for k in ('prompt_tokens','completion_tokens','total_tokens')):
            assert u['prompt_tokens']+u['completion_tokens']==u['total_tokens']
        model=z.get('model');reqmodel=(d.get('request_parameters') or {}).get('model')
        row=dict(output_id=m['output_id'],question_id=m['question_id'],company=m['company'],
            topic=grouping[m['question_id']]['topic'],mode=m['mode'],label=LABELS[m['mode']],
            status=m['status'],primary_status=m.get('primary_status'),recovered=bool(m.get('used_recovery')),
            elapsed_seconds=d.get('elapsed_seconds'),api_elapsed_seconds=d.get('api_elapsed_seconds'),
            response_model=model,requested_model=reqmodel,prompt_tokens=u.get('prompt_tokens'),
            completion_tokens=u.get('completion_tokens'),total_tokens=u.get('total_tokens'),
            reasoning_tokens=(u.get('completion_tokens_details') or {}).get('reasoning_tokens'))
        if m['status']=='completed':
            s=byqm[m['question_id'],m['mode']]
            for rating in ('R1','R2','mean'):
                for f in (*FIELDS,'total'):row[f'{rating}_{f}']=s[rating][f]
        flat.append(row)

    def value(q,m,r,f):return byqm.get((q,m),{}).get(r,{}).get(f)
    full=list(grouping)
    small=[r['question_id'] for r in freeze['robustness']['selection']]
    defs=[('G2-G1',MAIN[0],MAIN[1],full),('G3-G2',MAIN[1],MAIN[2],full),
          ('G3-G1',MAIN[0],MAIN[2],full),('G3-NoRerank',MAIN[3],MAIN[2],full),
          ('G3-BM25',MAIN[4],MAIN[2],full),('NoAnnual-G3',MAIN[2],'minus_annual',small),
          ('NoRegulation-G3',MAIN[2],'minus_regulation',small)]
    defs += [('K28-K3 '+LABELS[m],m,'k28__'+m,small) for m in MAIN[:3]]
    effects=[]
    for name,base,treat,questions in defs:
        for rating in ('mean','R1','R2'):
            for f in (*FIELDS,'total'):
                p=paired([(q,grouping[q]['company_cluster'],value(q,base,rating,f),value(q,treat,rating,f)) for q in questions],8 if f=='total' else 2)
                effects.append(dict(contrast=name,baseline=base,treatment=treat,rating=rating,dimension=f,**p))
    topics=[]
    for name,base,treat,questions in defs[:5]:
        for topic in ('D1','D2','D3'):
            qs=[q for q in questions if grouping[q]['topic']==topic]
            for f in (*FIELDS,'total'):
                p=paired([(q,grouping[q]['company_cluster'],value(q,base,'mean',f),value(q,treat,'mean',f)) for q in qs],8 if f=='total' else 2)
                topics.append(dict(contrast=name,topic=topic,dimension=f,**p))
    ceilings=[];distributions=[];summaries=[];agreements=[]
    for mode,label in LABELS.items():
        group=[s for s in scores if s['mode']==mode]
        for rating in ('mean','R1','R2'):
            for f in (*FIELDS,'total'):
                vals=[s[rating][f] for s in group if s[rating][f] is not None];maximum=8 if f=='total' else 2
                ceilings.append(dict(mode=mode,label=label,rating=rating,dimension=f,n=len(vals),
                    mean=float(np.mean(vals)),sd=float(np.std(vals,ddof=1)),
                    ceiling_n=sum(v==maximum for v in vals),ceiling_fraction=sum(v==maximum for v in vals)/len(vals)))
                for v,n in sorted(Counter(vals).items()):distributions.append(dict(mode=mode,label=label,rating=rating,dimension=f,score=v,n=n))
        for topic in ('D1','D2','D3'):
            sub=[s for s in group if grouping[s['question_id']]['topic']==topic]
            for f in (*FIELDS,'total'):
                vals=[s['mean'][f] for s in sub if s['mean'][f] is not None]
                summaries.append(dict(mode=mode,label=label,topic=topic,dimension=f,n=len(vals),mean=float(np.mean(vals)) if vals else None))
    for mode in ['ALL',*MAIN]:
        group=scores if mode=='ALL' else [s for s in scores if s['mode']==mode]
        for f in FIELDS:
            a=[s['R1'][f] for s in group];b=[s['R2'][f] for s in group]
            k=quadratic_kappa(a,b);d=np.array(b)-a
            agreements.append(dict(mode=mode,dimension=f,n=len(d),reviewer2_minus_1=float(d.mean()),
                absolute_difference=float(np.abs(d).mean()),r1_ceiling_fraction=sum(v==2 for v in a)/len(a),
                r2_ceiling_fraction=sum(v==2 for v in b)/len(b),**k))
    costs=[];structures=[];structure_outputs=[]
    for mode,label in LABELS.items():
        completed=[r for r in flat if r['mode']==mode and r['status']=='completed']
        planned=[r for r in flat if r['mode']==mode]
        result=dict(mode=mode,label=label,planned=len(planned),completed=len(completed),
            final_failures=len(planned)-len(completed),recovered=sum(r['recovered'] for r in completed),
            response_models=dict(Counter(r['response_model'] for r in completed)),
            requested_models=dict(Counter(r['requested_model'] for r in completed)))
        for f in ('elapsed_seconds','prompt_tokens','completion_tokens','total_tokens','reasoning_tokens'):
            vals=[r[f] for r in completed if isinstance(r[f],(int,float))]
            result[f+'_n']=len(vals);result[f+'_mean']=float(np.mean(vals)) if vals else None
            result[f+'_median']=float(np.median(vals)) if vals else None
            result[f+'_q25']=float(np.quantile(vals,.25)) if vals else None
            result[f+'_q75']=float(np.quantile(vals,.75)) if vals else None
        costs.append(result)
        claim_n=0;dual=0;unsupported_ids=0;cited_n=0;claims_status=Counter();overall=Counter()
        for r in completed:
            d=units[r['output_id']];response=d.get('response') or {};audit=d.get('citation_id_audit') or {}
            overall[response.get('overall_evidence_status')]+=1
            claims=response.get('claims') or []
            cn=dn=0
            for c in claims:
                ids=c.get('evidence_ids') or [];cn+=1;claim_n+=1
                claims_status[c.get('evidence_status')]+=1
                both=any(str(x).startswith('A') for x in ids) and any(str(x).startswith('R') for x in ids)
                dn+=int(both);dual+=int(both)
            unresolved=len(audit.get('unresolved_ids') or []);unsupported_ids+=unresolved
            cited=len(audit.get('cited_ids') or []);cited_n+=cited
            structure_outputs.append(dict(output_id=r['output_id'],mode=mode,claim_n=cn,
                dual_role_id_claims=dn,dual_role_id_claim_fraction=dn/cn if cn else None,
                cited_id_n=cited,unresolved_id_n=unresolved,
                self_declared_overall_status=response.get('overall_evidence_status')))
        structures.append(dict(mode=mode,label=label,completed=len(completed),claims=claim_n,
            claims_per_output=claim_n/len(completed),claims_with_A_and_R_id=dual,
            dual_role_id_claim_fraction=dual/claim_n if claim_n else None,
            unresolved_id_n=unsupported_ids,cited_id_n=cited_n,
            self_declared_claim_statuses=dict(claims_status),self_declared_overall_status=dict(overall)))
    report=dict(created_at_utc=datetime.now(timezone.utc).isoformat(),
        analysis_status='new_post_hoc_analysis_of_saved_experiment_and_accepted_human_scores',
        new_generation_calls=0,new_human_labels=0,independent_unit='company cluster',
        draws=DRAWS,seed=SEED,inputs_verified=True,source_units_verified=len(source_manifest),
        runtime=dict(python_executable=sys.executable,python_version=sys.version,numpy_version=np.__version__),
        input_hashes=[dict(file=str(p.resolve()),sha256=sha(p)) for p in inputs],
        definitions=dict(aggregation='Equal mean of two accepted reviewers per field; sum four fields for 0–8 total.',
            dimension_max=2,total_max=8,topic_labels={'D1':'Dividend disclosure','D2':'Audit committee','D3':'Internal control'},
            interval='Pointwise percentile company bootstrap conditional on observed paired outputs; no multiple-testing correction.',
            topic_analysis='Exploratory subgroup descriptions, not preregistered interaction tests.',
            sharp_bounds='Question-weighted full planned inventory; exploit known side of incomplete pairs; no quality zero imputation.',
            runtime='Selected saved successful attempt only; excludes prior failed attempts, retrieval/indexing and retries, and mixes logged conditions.',
            token_usage='Provider-reported tokens; includes provider completion/reasoning accounting; not model-independent tokenizer-normalized cost.',
            citation_structure='Syntactic ID audit and model-reported statuses only; neither semantic support nor legal applicability.'),
        paired_effects=effects,topic_effects=topics,ceiling=ceilings,agreement=agreements,
        quality_by_topic=summaries,selected_attempt_cost=costs,structural_proxies=structures,
        limitations=['All added analyses are post hoc.',
            '20 company clusters and three narrow topics limit external validity.',
            'Only one selected generation per condition/question; no stochastic-repeat uncertainty estimate.',
            'Ceiling effects and reviewer regulation disagreement limit rubric discrimination.',
            'No claim-level human semantic-support or time-applicability labels added.',
            'Observed-only bootstrap intervals do not remove outcome-dependent failure selection.',
            'Logged latency is descriptive, not controlled end-to-end efficiency evidence.',
            'These analyses do not certify journal acceptance, legal correctness or deployment readiness.'])
    dump('quality_extensions.json',report);dump('source_unit_manifest.json',source_manifest)
    csvout('per_output_verified.csv',flat)
    csvout('paired_dimension_effects.csv',[{k:(json.dumps(v) if isinstance(v,(list,dict)) else v) for k,v in r.items()} for r in effects])
    csvout('topic_effects.csv',[{k:(json.dumps(v) if isinstance(v,(list,dict)) else v) for k,v in r.items()} for r in topics])
    csvout('score_ceiling.csv',ceilings);csvout('score_distributions.csv',distributions)
    csvout('quality_by_topic.csv',summaries)
    csvout('selected_attempt_cost.csv',[{k:(json.dumps(v) if isinstance(v,(list,dict)) else v) for k,v in r.items()} for r in costs])
    csvout('structure_proxy_by_output.csv',structure_outputs)
    csvout('structure_proxy_summary.csv',[{k:(json.dumps(v) if isinstance(v,(list,dict)) else v) for k,v in r.items()} for r in structures])
    cases = qualitative_cases(scores,mapping,units,grouping,reviews,intake)
    dump('qualitative_cases.json',cases)
    plot(report)
    findings(report)
    dump('artifact_manifest.json',[dict(file=str(p.relative_to(OUT)),sha256=sha(p),bytes=p.stat().st_size) for p in sorted(OUT.rglob('*')) if p.is_file() and p.name!='artifact_manifest.json'])
    print('Created quality analysis:',str(OUT),'\nVerified sources:',len(source_manifest),'\nArtifacts:',len(list(OUT.rglob('*'))))

def plot(r):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,
        'axes.spines.right':False,'savefig.dpi':220,'pdf.fonttype':42,'svg.fonttype':'none'})
    def save(fig,name):
        fig.tight_layout()
        for ext in ('png','pdf','svg'):fig.savefig(OUT/(name+'.'+ext),bbox_inches='tight')
        plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(11,4.4))
    for ax,contrast in zip(axes,['G2-G1','G3-G2']):
        dims=list(FIELDS)
        for rating,offset,color in [('R1',-.18,'#8b99a4'),('mean',0,'#137e91'),('R2',.18,'#c18447')]:
            for i,f in enumerate(dims):
                x=next(t for t in r['paired_effects'] if t['contrast']==contrast and t['dimension']==f and t['rating']==rating)
                v=x['macro_delta'];ci=x['ci95']
                ax.errorbar(v,i+offset,xerr=[[max(0,v-ci[0])],[max(0,ci[1]-v)]],fmt='o',color=color,capsize=3,ms=4,label=rating if i==0 else None)
        ax.axvline(0,color='.4',lw=1);ax.set_title(contrast);ax.set_yticks(range(4),[DIMLABELS[f] for f in dims]);ax.invert_yaxis();ax.grid(axis='x',alpha=.2);ax.set_xlabel('Paired company mean change (0–2 rubric)')
    axes[0].legend(loc='best');save(fig,'quality_dimension_effects')
    fig,axes=plt.subplots(1,2,figsize=(10.6,4.4))
    for ax,contrast in zip(axes,['G2-G1','G3-G2']):
        for i,topic in enumerate(['D1','D2','D3']):
            t=next(t for t in r['topic_effects'] if t['contrast']==contrast and t['dimension']=='total' and t['topic']==topic)
            v=t['macro_delta'];ci=t['ci95'];ax.errorbar(v,i,xerr=[[max(0,v-ci[0])],[max(0,ci[1]-v)]],fmt='o',color='#137e91',capsize=4)
        counts=[next(t for t in r['topic_effects'] if t['contrast']==contrast and t['dimension']=='total' and t['topic']==topic) for topic in ('D1','D2','D3')]
        labels=[f"{name} ({t['known']}/{t['planned']})" for name,t in zip(['D1: Dividend','D2: Audit committee','D3: Internal control'],counts)]
        ax.axvline(0,color='.4',lw=1);ax.set_title(contrast);ax.set_yticks(range(3),labels);ax.invert_yaxis();ax.set_xlabel('Paired company change in total quality (0–8)');ax.grid(axis='x',alpha=.2)
    save(fig,'quality_topic_effects')
    fig,axes=plt.subplots(1,2,figsize=(11.2,4.8),gridspec_kw={'width_ratios':[1.25,1]})
    dims=list(FIELDS)
    data=np.array([[next(t['ceiling_fraction'] for t in r['ceiling'] if t['mode']==m and t['rating']=='mean' and t['dimension']==f) for f in dims] for m in MAIN])
    axes[0].imshow(data,vmin=0,vmax=1,cmap='Blues')
    for i in range(len(MAIN)):
        for j in range(4):axes[0].text(j,i,f'{data[i,j]:.1%}',ha='center',va='center',color='white' if data[i,j]>.65 else '#173648')
    axes[0].set_yticks(range(len(MAIN)),[LABELS[m] for m in MAIN]);axes[0].set_xticks(range(4),['Facts','Regulation','Citations','Uncertainty'],rotation=25,ha='right');axes[0].set_title('(a) Both-reviewer maximum score fraction')
    for rating,offset,color in [('R1',-.18,'#8b99a4'),('R2',.18,'#c18447')]:
        vals=[next(t['r1_ceiling_fraction' if rating=='R1' else 'r2_ceiling_fraction'] for t in r['agreement'] if t['mode']=='ALL' and t['dimension']==f) for f in dims]
        axes[1].barh(np.arange(4)+offset,vals,height=.33,label=rating,color=color)
    axes[1].set_yticks(range(4),['Facts','Regulation','Citations','Uncertainty']);axes[1].invert_yaxis();axes[1].set_xlim(0,1.05);axes[1].set_xlabel('Maximum-score fraction (all 386 outputs)');axes[1].set_title('(b) Reviewer-specific ceiling');axes[1].legend(loc='lower right')
    save(fig,'quality_ceiling_diagnostics')
    fig,axes=plt.subplots(1,2,figsize=(11.2,4.4))
    for ax,field,ylabel in zip(axes,['elapsed_seconds','total_tokens'],['Selected-attempt latency (seconds)','Provider-reported total tokens']):
        for i,m in enumerate(MAIN):
            t=next(t for t in r['selected_attempt_cost'] if t['mode']==m)
            median=t[field+'_median'];lo=t[field+'_q25'];hi=t[field+'_q75']
            ax.errorbar(i,median,yerr=[[median-lo],[hi-median]],fmt='o',capsize=4,color='#137e91')
        ax.set_xticks(range(len(MAIN)),[LABELS[m] for m in MAIN],rotation=20,ha='right');ax.set_ylabel(ylabel);ax.grid(axis='y',alpha=.2)
    save(fig,'selected_attempt_resource_profile')
    fig,axes=plt.subplots(1,2,figsize=(11,4.4))
    subset=[next(t for t in r['structural_proxies'] if t['mode']==m) for m in MAIN]
    axes[0].bar(range(5),[t['claims_per_output'] for t in subset],color='#137e91')
    axes[1].bar(range(5),[t['dual_role_id_claim_fraction'] for t in subset],color='#c18447')
    for ax in axes:ax.set_xticks(range(5),[LABELS[m] for m in MAIN],rotation=20,ha='right');ax.grid(axis='y',alpha=.2)
    axes[0].set_ylabel('Model-enumerated claims per output');axes[1].set_ylabel('Claims listing both A and R IDs (fraction)');axes[1].set_ylim(0,1)
    fig.suptitle('Structural output proxies: semantic support is not measured',fontsize=11)
    save(fig,'citation_structure_proxies')

def findings(r):
    lines=['新增质量分析（2026-10-23）','本次为对已保存输出与真实双人评分的新增后验统计分析；未发起 API、未生成新人工标签。','已核验 400 条来源 SHA-256，并逐项与两份已验收评分重建值核对。',
        '统计单位：公司聚类；10,000 次百分位 bootstrap；seed=20261023；点态 95% 区间，不作多重比较校正。','',
        '配对总分：公司宏均差；区间条件于已观测配对；全清单界限为问题加权且保留缺失对中的已知一侧。']
    for t in r['paired_effects']:
        if t['rating']=='mean' and t['dimension']=='total':
            lo,hi=t['ci95'];a,b=t['full_inventory_question_mean_sharp_bounds']
            lines.append(f"{t['contrast']}: n={t['known']}/{t['planned']}, delta={t['macro_delta']:.4f}, CI=[{lo:.4f},{hi:.4f}], sharp bounds=[{a:.4f},{b:.4f}], wins/ties/losses={t['win']}/{t['tie']}/{t['loss']}")
    lines+=['','维度效果（两人均分，分值 0–2）：']
    for t in r['paired_effects']:
        if t['rating']=='mean' and t['contrast'] in ('G2-G1','G3-G2') and t['dimension']!='total':
            lines.append(f"{t['contrast']} / {t['dimension']}: {t['macro_delta']:.4f}, CI={t['ci95']}, n={t['known']}")
    lines+=['','主题异质性（后验描述，不作确证性交互效应解释）：']
    for t in r['topic_effects']:
        if t['contrast'] in ('G2-G1','G3-G2') and t['dimension']=='total':
            lines.append(f"{t['contrast']} {t['topic']}: {t['macro_delta']:.4f}, CI={t['ci95']}, n={t['known']}")
    lines+=['','评分分辨力与评分者敏感性：']
    for t in r['agreement']:
        if t['mode']=='ALL':
            lines.append(f"{t['dimension']}: R2-R1={t['reviewer2_minus_1']:.4f}, 精确一致率={t['exact_agreement_including_unknown']:.4f}, kappa={t['quadratic_weighted_kappa_on_numeric_judgments']}, R1/R2满分率={t['r1_ceiling_fraction']:.3%}/{t['r2_ceiling_fraction']:.3%}")
    lines+=['','解释边界：引用与不确定性维度有明显天花板效应。近乎满分不能解释为语义支持、法律适用或真实应用的准确率；法规评分者系统性偏移需在讨论中解释。',
        '日志中的 token 和延迟只覆盖最终选取成功调用，混合并发、恢复与不同运行条件；不含之前失败调用、检索与索引，不可当作端到端耗时或货币成本优势。',
        '输出中的 claims/evidence_status 是模型自报字段。A/R 双角色 ID 同现和无未知 ID 都只是结构指标，不能证明证据支持。',
        '全部结果为后验分析；不更改已有评分；不宣称新增严格人工语义金标，不以这些分析保证期刊接收。','',
        '建议纳入正文：quality_dimension_effects、quality_topic_effects、quality_ceiling_diagnostics；资源与引用结构图可放附录。',
        '建议表：paired_dimension_effects.csv 中 mean 总分与四维效果；quality_by_topic.csv 的 G1/G2/G3；selected_attempt_cost.csv 的五主条件；评分者一致性从 quality_extensions.json agreement 提取。']
    (OUT/'新增分析发现.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8-sig')

def qualitative_cases(scores,mapping,units,grouping,reviews,intake):
    byqm={(r['question_id'],r['mode']):r for r in scores}
    byid={m['output_id']:m for m in mapping}
    candidates=[]
    for q in grouping:
        if not all((q,m) in byqm for m in MAIN[:3]): continue
        a,b,c=[byqm[q,m]['mean']['total'] for m in MAIN[:3]]
        candidates.append((q,a,b,c))
    selected=[]
    # Deterministic case selection from the distribution, retaining ties as ties.
    pools=[('positive_G2_minus_G1',sorted(candidates,key=lambda x:(-(x[2]-x[1]),x[0]))),
           ('negative_G3_minus_G2',sorted(candidates,key=lambda x:((x[3]-x[2]),x[0]))),
           ('null_all_three',[x for x in candidates if x[1]==x[2]==x[3]]),
           ('positive_G3_minus_G2',sorted(candidates,key=lambda x:(-(x[3]-x[2]),x[0])))]
    for label,pool in pools:
        item=next((x for x in pool if x[0] not in {s[0] for s in selected}),None)
        if item:selected.append((item[0],label,*item[1:]))
    out=[]
    for q,label,a,b,c in selected:
        case=dict(question_id=q,selection_rule=label,topic=grouping[q]['topic'],
                  total_mean_G1=a,total_mean_G2=b,total_mean_G3=c,outputs=[])
        for m in MAIN[:3]:
            s=byqm[q,m];ref=byid[s['output_id']];d=units[s['output_id']]
            response=d.get('response') or {};body=response.get('evaluation') or ''
            audit=d.get('citation_id_audit') or {}
            notes={}
            for i,review in enumerate(reviews):
                idx=next(j for j,v in enumerate(review['judgments']) if v['output_id']==s['output_id'])
                notes[f'R{i+1}']=dict(note=review['judgments'][idx].get('note',''),
                    source_file=intake['accepted_reviews'][i]['file'],
                    field=f'judgments[{idx}].note')
            case['outputs'].append(dict(mode=m,label=LABELS[m],output_id=s['output_id'],
                source_file=ref['source_file'],source_sha256=ref['source_sha256'],
                excerpt_field='response.evaluation',excerpt_verbatim=body[:120],
                excerpt_start=0,excerpt_characters=min(120,len(body)),
                body_characters=len(body),source_ids=audit.get('cited_ids'),
                scores={rating:s[rating] for rating in ('R1','R2','mean')},
                accepted_reviewer_notes=notes,
                first_claim=response.get('claims',[None])[0] if response.get('claims') else None,
                first_claim_field='response.claims[0]'))
        out.append(case)
    return dict(selection_timing='Post hoc case selection using human score differences; examples are descriptive, not causal.',
        excerpts='Exact first 120 Unicode characters of response.evaluation, no ellipsis inserted into quoted text.',
        score_interpretation='Four dimensions in order company_facts/regulation/citations/uncertainty; IDs are syntactic source references.',cases=out)

if __name__=='__main__': main()
