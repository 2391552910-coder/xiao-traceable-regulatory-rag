"""Publication plots and coverage audit from executed cached-ranking replay."""
from __future__ import annotations
import csv
import json
import sys
from collections import defaultdict
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from scripts.replay_cached_retrieval_diagnostics_20261023 import OUT,RUN,load,source_hash,page_key,ref_key,sha,write_json,write_csv
from src.data.page_reference_release import load_page_reference_release


def main():
    rows=list(csv.DictReader((OUT/'replay_per_question.csv').open(encoding='utf-8-sig')))
    sums=load(OUT/'replay_summary.json')
    plan=load(RUN/'execution_plan.json'); idx=Path(plan['index_dir'])
    chunks=[json.loads(line) for line in (idx/'chunks.jsonl').read_text(encoding='utf-8').splitlines()]
    chunks=[c for c in chunks if c['doc_id'] not in plan['excluded_superseded_doc_ids']]
    release=load_page_reference_release(plan['reference_dir'],plan['reference_manifest_sha256'])
    pagekeys={page_key(c) for c in chunks}
    missing=[eid for eid,ev in release.evidence.items() if ref_key(ev) not in pagekeys]
    audit=[]
    for strategy in ['merged','dual']:
        for topic in ['ALL','AUDIT_COMMITTEE','DIVIDEND_DISCLOSURE','INTERNAL_CONTROL']:
            candidates=[r for r in rows if r['strategy']==strategy and r['quota']=='10' and r['budget_tokens']=='8000' and (topic=='ALL' or r['topic']==topic)]
            baseline={r['question_id']:r for r in rows if r['strategy']==strategy and r['quota']=='10' and r['budget_tokens']=='6000'}
            n=len(candidates)
            audit.append(dict(strategy=strategy,topic=topic,questions=n,
                candidate_law_reference_hit=sum(int(r['law_any_reference_page']) for r in candidates),
                selected_law_reference_hit=sum(int(baseline[r['question_id']]['law_any_reference_page']) for r in candidates),
                candidate_annual_reference_hit=sum(int(r['annual_any_reference_page']) for r in candidates),
                selected_annual_reference_hit=sum(int(baseline[r['question_id']]['annual_any_reference_page']) for r in candidates),
                candidate_contains_both_reference_roles=sum(int(r['both_reference_roles_available']) for r in candidates),
                selected_contains_both_reference_roles=sum(int(baseline[r['question_id']]['both_reference_roles_available']) for r in candidates)))
    write_csv(OUT/'candidate_vs_packing_audit.csv',audit)
    write_json(OUT/'index_reference_page_availability.json',dict(reference_records=len(release.evidence),
        reference_records_with_exact_source_page_available=len(release.evidence)-len(missing),missing_evidence_ids=missing,
        statement='Exact source SHA and physical page available in index; neither chunk semantic support nor exhaustive relevance is inferred.'))
    figdir=OUT/'figures'; figdir.mkdir(exist_ok=True)
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.labelsize':9,
        'axes.titlesize':10,'axes.spines.top':False,'axes.spines.right':False,
        'svg.fonttype':'none','pdf.fonttype':42,'savefig.dpi':220})
    colors={'merged':'#526B8A','dual':'#C96F35'}
    labels={'merged':'G1: merged retrieval','dual':'G2: role-balanced retrieval'}
    def save(fig,name):
        for ext in ['png','svg','pdf']:
            fig.savefig(figdir/(name+'.'+ext),bbox_inches='tight',facecolor='white')
        plt.close(fig)
    fig,axs=plt.subplots(1,3,figsize=(11.2,3.1))
    for s in ['merged','dual']:
        sub=sorted([r for r in sums if r['strategy']==s and r['quota']==10 and r['topic']=='ALL'],key=lambda x:x['budget_tokens'])
        for ax,key,title in zip(axs,['has_both_roles_mean','both_reference_roles_available_mean','annual_page_coverage_mean'],
            ['Any annual + any law evidence','Both reference roles available','Annual reference-page coverage']):
            ax.plot([r['budget_tokens'] for r in sub],[100*r[key] for r in sub],'-o',lw=1.8,ms=4,color=colors[s],label=labels[s])
            ax.set_title(title);ax.set_xlabel('Reference-token cap');ax.grid(axis='y',alpha=.18);ax.set_ylim(-3,103)
            ax.set_xticks([1000,2000,4000,6000,8000],['1k','2k','4k','6k','8k'])
    axs[0].set_ylabel('Matched questions / coverage (%)')
    axs[0].legend(frameon=False,fontsize=8,loc='lower right')
    fig.text(.5,-.015,'Frozen top-10 candidates; whole-chunk packing. Reference-page hits do not establish semantic support.',ha='center',fontsize=8)
    fig.tight_layout();save(fig,'R1_budget_sensitivity')
    fig,axs=plt.subplots(1,2,figsize=(9,3.3))
    topics=['AUDIT_COMMITTEE','DIVIDEND_DISCLOSURE','INTERNAL_CONTROL']
    x=np.arange(3);width=.32
    for i,s in enumerate(['merged','dual']):
        sub=[next(r for r in sums if r['strategy']==s and r['quota']==10 and r['budget_tokens']==6000 and r['topic']==t) for t in topics]
        for ax,key,title in zip(axs,['annual_page_coverage_mean','law_page_coverage_mean'],['Annual reference pages','Law reference locations']):
            bars=ax.bar(x+(i-.5)*width,[100*r[key] for r in sub],width,color=colors[s],label=labels[s])
            ax.bar_label(bars,fmt='%.1f',fontsize=8,padding=3);ax.set_title(title)
            ax.set_xticks(x,['Audit\ncommittee','Dividend\ndisclosure','Internal\ncontrol']);ax.set_ylim(0,103);ax.grid(axis='y',alpha=.18);ax.set_axisbelow(True)
    axs[0].set_ylabel('Macro reference-location coverage (%)');axs[1].legend(frameon=False,fontsize=8)
    fig.text(.5,-.015,'20 questions/topic; 6k cap, top-10. Locations are PDF pages or the whole DOC004 TXT; references are non-exhaustive.',ha='center',fontsize=8)
    fig.tight_layout();save(fig,'R2_topic_page_coverage')
    fig,axs=plt.subplots(1,2,figsize=(8.8,3.3))
    base=[r for r in rows if r['quota']=='10' and r['budget_tokens']=='6000']
    for ax,metric,title,ylabel in zip(axs,['annual_chunks','reference_tokens'],['Evidence allocation','Actual context length'],['Annual chunks per context','Reference tokens']):
        groups=[[float(r[metric]) for r in base if r['strategy']==s] for s in ['merged','dual']]
        boxes=ax.boxplot(groups,patch_artist=True,widths=.42,tick_labels=['G1 merged','G2 balanced'],showfliers=False)
        for box,s in zip(boxes['boxes'],['merged','dual']):box.set_facecolor(colors[s]);box.set_alpha(.5)
        for med in boxes['medians']:med.set_color('#17242F');med.set_linewidth(1.5)
        for i,ys in enumerate(groups,1):
            jitter=np.linspace(-.13,.13,len(ys))
            ax.scatter(np.full(len(ys),i)+jitter,ys,s=7,c=colors[['merged','dual'][i-1]],alpha=.45,zorder=3)
        ax.set_title(title);ax.set_ylabel(ylabel);ax.grid(axis='y',alpha=.18)
    axs[0].set_ylim(-.4,10.7)
    fig.text(.5,-.015,'Each dot is one of 60 matched questions. Reference tokens use the frozen Qwen tokenizer, not provider billing.',ha='center',fontsize=8)
    fig.tight_layout();save(fig,'R3_context_allocation')
    figure_receipt=[dict(path=str(p),sha256=sha(p)) for p in sorted(figdir.iterdir())]
    write_json(OUT/'figure_manifest.json',figure_receipt)
    print(json.dumps({'full_index_reference_page_availability':f'{len(release.evidence)-len(missing)}/{len(release.evidence)}','missing_ids':missing,'stage_audit':audit},ensure_ascii=False))


if __name__=='__main__':main()
