"""Recompute core paper contrasts from the two accepted reviewer submissions.

This audit preserves the manuscript's exploratory equal-mean aggregation. It
does not adjudicate reviewer disagreements or treat the resulting scores as a
consensus gold standard.
"""
from __future__ import annotations

import argparse
from collections import defaultdict
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from scripts.score_minimal_paper_reviews import FIELDS, compare, validate_submission
from src.metrics.compact_paper_statistics import paired_company_statistics, quadratic_kappa


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def close(a, b) -> bool:
    if isinstance(a, (list, tuple)) or isinstance(b, (list, tuple)):
        return (
            isinstance(a, (list, tuple))
            and isinstance(b, (list, tuple))
            and len(a) == len(b)
            and all(close(x, y) for x, y in zip(a, b))
        )
    if a is None or b is None:
        return a is b
    return math.isclose(float(a), float(b), rel_tol=0.0, abs_tol=1e-12)


def main() -> None:
    runs = ROOT / "results" / "runs"
    review_root = runs / "paper_actual_output_review_windows_20261021_01"
    package = review_root / "当前唯一使用包"
    mapping_path = review_root / "coordinator_private_mapping.json"
    r1_path = runs / "round2_owner_confirmed_windows_20261023_01" / "accepted_submissions" / "A-7402_提交.json"
    r2_path = runs / "round2_owner_confirmed_windows_20261023_01" / "accepted_submissions" / "B-9136_提交.json"
    freeze_path = runs / "paper_execution_freeze_windows_20261020_01" / "execution_freeze.json"
    prior_root = runs / "two_reviewer_statistics_windows_20261023_01"
    out_path = runs / "paper_claim_recalc_20261027_01" / "recalculation.json"

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=out_path)
    args = parser.parse_args()
    output = args.out if args.out.is_absolute() else ROOT / args.out
    if output.exists():
        raise FileExistsError(f"Refusing to overwrite existing audit: {output}")

    package_manifest = load_json(package / "package_manifest.json")
    for entry in package_manifest["files"]:
        candidate = (package / entry["file"]).resolve()
        if not candidate.is_relative_to(package.resolve()) or sha256(candidate) != entry["sha256"]:
            raise ValueError(f"Review package integrity failed: {entry['file']}")

    mapping = load_json(mapping_path)
    receipt = load_json(review_root / "delivery_receipt.json")
    if sha256(mapping_path) != receipt["private_coordinator_mapping_sha256"]:
        raise ValueError("Coordinator mapping hash differs from its delivery receipt")
    expected = {row["output_id"]: row for row in mapping if row["status"] == "completed"}
    mapping_status_counts = dict(sorted(Counter(row["status"] for row in mapping).items()))
    first, second = load_json(r1_path), load_json(r2_path)
    ratings_a = validate_submission(first, expected)
    ratings_b = validate_submission(second, expected)
    _, disagreements = compare(first, second, expected)

    agreement = {}
    exact_cells = 0
    dimension_mean_delta = {}
    for field in FIELDS:
        values_a = [ratings_a[key][field] for key in expected]
        values_b = [ratings_b[key][field] for key in expected]
        exact_cells += sum(a == b for a, b in zip(values_a, values_b))
        agreement[field] = quadratic_kappa(values_a, values_b)
        dimension_mean_delta[field] = sum(b - a for a, b in zip(values_a, values_b)) / len(values_a)

    by_question_mode: dict[tuple[str, str], float] = {}
    means_by_output: dict[str, float] = {}
    for output_id, row in expected.items():
        mean_total = sum((ratings_a[output_id][field] + ratings_b[output_id][field]) / 2 for field in FIELDS)
        means_by_output[output_id] = mean_total
        by_question_mode[(row["question_id"], row["mode"])] = mean_total

    mode_values = defaultdict(list)
    for output_id, row in expected.items():
        mode_values[row["mode"]].append((row["company"], means_by_output[output_id]))
    condition_summaries = {}
    for mode, values in sorted(mode_values.items()):
        by_company = defaultdict(list)
        for company, score in values:
            by_company[company].append(score)
        condition_summaries[mode] = {
            "known_outputs": len(values),
            "answer_mean": sum(score for _, score in values) / len(values),
            "company_macro": sum(sum(scores) / len(scores) for scores in by_company.values()) / len(by_company),
        }

    freeze = load_json(freeze_path)
    registered = freeze["grouping"]
    contrast_specs = {
        "G2-G1": ("merged_corpus_generic_cited_rag", "dual_source_generic_cited_rag"),
        "G3-G2": ("dual_source_generic_cited_rag", "dual_source_role_grounded_rag"),
    }
    recomputed = {}
    for label, (baseline, treatment) in contrast_specs.items():
        rows = [
            {
                "question_id": q["question_id"],
                "company": q["company_cluster"],
                "baseline": by_question_mode.get((q["question_id"], baseline)),
                "treatment": by_question_mode.get((q["question_id"], treatment)),
            }
            for q in registered
        ]
        recomputed[label] = paired_company_statistics(rows, draws=2000, seed=42)

    old_scores = load_json(prior_root / "per_output_scores.json")
    old_by_id = {r["output_id"]: r["mean"]["total"] for r in old_scores}
    if set(old_by_id) != set(means_by_output):
        raise ValueError("Recomputed output inventory differs from the saved score inventory")
    output_means_match = all(close(old_by_id[key], value) for key, value in means_by_output.items())

    old_statistics = load_json(prior_root / "statistics.json")
    execution_inventory = {
        "planned_outputs": len(mapping),
        "status_counts": mapping_status_counts,
        "completed_outputs": len(expected),
        "recovered_completed_outputs": sum(bool(row.get("used_recovery")) for row in expected.values()),
    }
    execution_inventory_matches = (
        execution_inventory["planned_outputs"] == old_statistics["planned_outputs"]
        and execution_inventory["completed_outputs"] == old_statistics["available_outputs"]
        and len(mapping) - len(expected) == old_statistics["failed_outputs"]
        and len(means_by_output) == len(expected)
    )
    condition_matches = {}
    for mode, summary in condition_summaries.items():
        prior = old_statistics["summaries"][mode]["ratings"]["mean"]
        condition_matches[mode] = (
            summary["known_outputs"] == prior["known"]
            and close(summary["answer_mean"], prior["answer_mean"])
            and close(summary["company_macro"], prior["company_macro"])
        )
    agreement_matches = {}
    for field, value in agreement.items():
        prior = old_statistics["agreement"][field]
        agreement_matches[field] = close(
            value["quadratic_weighted_kappa_on_numeric_judgments"],
            prior["quadratic_weighted_kappa_on_numeric_judgments"],
        ) and close(value["exact_agreement_including_unknown"], prior["exact_agreement_including_unknown"])
    comparisons_match = {}
    for label, result in recomputed.items():
        prior = old_statistics["contrasts"][label]["mean"]
        comparisons_match[label] = all(
            close(result[field], prior[field])
            for field in (
                "known_pairs",
                "unknown_pairs",
                "company_macro_difference_on_known_pairs",
                "company_cluster_bootstrap_ci95",
                "full_test_difference_bounds",
            )
        )

    provenance_paths = [r1_path, r2_path, mapping_path, freeze_path]
    prior_hashes = {entry["file"]: entry["sha256"] for entry in old_statistics["input_hashes"]}
    for path in provenance_paths:
        expected_hash = prior_hashes.get(str(path))
        if expected_hash is not None and sha256(path) != expected_hash:
            raise ValueError(f"Input hash differs from prior statistics provenance: {path.name}")

    result = {
        "status": "recomputed_from_accepted_reviews",
        "scope": "Core observed-pair contrasts only; exploratory equal mean of two reviewers.",
        "reviewers": [first["reviewer_id"], second["reviewer_id"]],
        "reviewed_outputs": len(expected),
        "execution_inventory": execution_inventory,
        "execution_inventory_matches_saved_statistics": execution_inventory_matches,
        "reviewer_disagreement_cells": len(disagreements),
        "exactly_agreed_score_cells": exact_cells,
        "exact_score_cell_fraction": exact_cells / (len(expected) * len(FIELDS)),
        "reviewer_agreement": agreement,
        "reviewer_2_minus_reviewer_1_dimension_mean": dimension_mean_delta,
        "agreement_matches_saved_statistics": agreement_matches,
        "adjudication_performed": False,
        "reviewer_identity_authenticated_by_tool": False,
        "output_total_means_match_saved_inventory": output_means_match,
        "condition_summaries": condition_summaries,
        "condition_summaries_match_saved_statistics": condition_matches,
        "contrasts_match_saved_statistics": comparisons_match,
        "contrasts": recomputed,
        "limitations": [
            "The equal-mean analysis is not adjudication or a consensus gold standard.",
            "The interval is conditional on observed pairs; missing responses are not quality zeroes.",
            "The post-rating analysis is exploratory, not a preregistered confirmatory result.",
        ],
        "input_sha256": {str(path.relative_to(ROOT)): sha256(path) for path in provenance_paths},
        "prior_score_inventory_sha256": sha256(prior_root / "per_output_scores.json"),
        "prior_statistics_sha256": sha256(prior_root / "statistics.json"),
    }
    if (
        not output_means_match
        or not all(condition_matches.values())
        or not all(comparisons_match.values())
        or not all(agreement_matches.values())
        or not execution_inventory_matches
    ):
        result["status"] = "mismatch_detected"
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "status": result["status"],
        "reviewed_outputs": result["reviewed_outputs"],
        "execution_inventory": result["execution_inventory"],
        "execution_inventory_matches_saved_statistics": execution_inventory_matches,
        "reviewer_disagreement_cells": result["reviewer_disagreement_cells"],
        "exactly_agreed_score_cells": result["exactly_agreed_score_cells"],
        "exact_score_cell_fraction": result["exact_score_cell_fraction"],
        "output_total_means_match_saved_inventory": output_means_match,
        "condition_summaries_match_saved_statistics": condition_matches,
        "contrasts_match_saved_statistics": comparisons_match,
        "agreement_matches_saved_statistics": agreement_matches,
        "regulation_kappa": agreement["regulation"]["quadratic_weighted_kappa_on_numeric_judgments"],
        "regulation_reviewer2_minus_reviewer1": dimension_mean_delta["regulation"],
        "G2-G1_company_macro": recomputed["G2-G1"]["company_macro_difference_on_known_pairs"],
        "G3-G2_company_macro": recomputed["G3-G2"]["company_macro_difference_on_known_pairs"],
        "output": str(output),
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
