param([Parameter(Mandatory=$true)][string]$DocumentPath, [string]$QaSubfolder='qa')
$ErrorActionPreference = 'Stop'
$resolvedDocument = (Resolve-Path -LiteralPath $DocumentPath).Path
$qaDirectory = Join-Path (Split-Path -Parent $resolvedDocument) $QaSubfolder
New-Item -ItemType Directory -Path $qaDirectory -Force | Out-Null
$pdfPath = Join-Path $qaDirectory 'paper_native.pdf'
if (Test-Path -LiteralPath $pdfPath) { throw 'Preserve existing rendering' }
$beforeHash = (Get-FileHash -LiteralPath $resolvedDocument -Algorithm SHA256).Hash
$nativeApplication = New-Object -ComObject Kwps.Application
$readOnlyDocument = $null
$renderTimer = [System.Diagnostics.Stopwatch]::StartNew()
try {
    $readOnlyDocument = $nativeApplication.Documents.Open($resolvedDocument, $false, $true, $false)
    $readOnlyDocument.ExportAsFixedFormat($pdfPath, 17)
}
finally {
    if ($null -ne $readOnlyDocument) {
        $readOnlyDocument.Close(0)
        [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($readOnlyDocument)
    }
    [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($nativeApplication)
}
$renderTimer.Stop()
$afterHash = (Get-FileHash -LiteralPath $resolvedDocument -Algorithm SHA256).Hash
if ($beforeHash -ne $afterHash) { throw 'Source document changed during read-only export' }
if (-not (Test-Path -LiteralPath $pdfPath)) { throw 'Native PDF export did not create a file' }
@{
    method='WPS native read-only ExportAsFixedFormat'; success=$true;
    source_sha256=$afterHash.ToLower(); pdf_sha256=(Get-FileHash -LiteralPath $pdfPath -Algorithm SHA256).Hash.ToLower();
    elapsed_seconds=$renderTimer.Elapsed.TotalSeconds; source_unchanged=$true;
    only_this_readonly_document_closed=$true; application_quit_called=$false
} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $qaDirectory 'native_render_receipt.json') -Encoding utf8
Write-Output $pdfPath
