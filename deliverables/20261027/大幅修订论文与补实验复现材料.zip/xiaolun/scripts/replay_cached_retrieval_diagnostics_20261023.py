"""Post-hoc CPU replay of frozen retrieved candidates; no neural or API calls.

Run with the project's .venv-data Python. Page coverage and role availability
are structural diagnostics, never semantic relevance or answer quality scores.
"""
from __future__ import annotations

import csv
import hashlib
import json
import sys
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
from tokenizers import Tokenizer

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from src.data.clause_splitter import Chunk
from src.data.page_reference_release import load_page_reference_release
from src.generation.comparison import _pack_context

OUT = ROOT / 'results/paper/substantial_revision_20261023_01/retrieval'
RUN = ROOT / 'results/runs/compact_final_execution_windows_20261020_01'
CAPS = [1000, 2000, 4000, 6000, 8000]
QUOTAS = [2, 6, 10]


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def load(path):
    return json.loads(Path(path).read_bytes())


def write_json(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def write_csv(path, rows):
    fields = list(dict.fromkeys(key for row in rows for key in row))
    with path.open('w', encoding='utf-8-sig', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def source_hash(c):
    m = c['meta']
    return m.get('source_pdf_sha256') or m.get('source_document_sha256')


def page_key(c):
    return source_hash(c), c['meta'].get('physical_pdf_page_1based')


def ref_key(ev):
    return ev['source_sha256'], ev['physical_pdf_page_1based']


def shingle(text, n=12):
    # Text normalization alone: do not infer that matching text supports a claim.
    text = ''.join(text.split())
    return {text[i:i+n] for i in range(max(0, len(text)-n+1))}


def diagnostics(context, q, release):
    selected = context['source_records']
    roles = Counter(c['meta']['corpus_type'] for c in selected)
    refs = release.references_for(q['question_id'])
    refsets = {role: {ref_key(e) for e in refs if e['role'] == role}
               for role in ['annual_report', 'regulation']}
    selected_pages = {page_key(c) for c in selected if source_hash(c)}
    result = {
        'selected_chunks': len(selected), 'annual_chunks': roles['annual_report'],
        'regulation_chunks': roles['regulation'],
        'reference_tokens': context['reference_tokens'],
        'annual_fraction': roles['annual_report'] / len(selected) if selected else 0,
        'has_both_roles': int(all(roles[r] for r in ['annual_report','regulation'])),
        'unique_source_documents': len({source_hash(c) or c['doc_id'] for c in selected}),
        'omitted_candidates': len(context['omitted_candidates']),
    }
    for role, short in [('annual_report', 'annual'), ('regulation', 'law')]:
        matches = refsets[role] & selected_pages
        result[short + '_reference_pages'] = len(refsets[role])
        result[short + '_reference_page_hits'] = len(matches)
        result[short + '_page_coverage'] = len(matches) / len(refsets[role])
        result[short + '_any_reference_page'] = int(bool(matches))
    result['both_reference_roles_available'] = int(result['annual_any_reference_page'] and result['law_any_reference_page'])
    allrefs = refsets['annual_report'] | refsets['regulation']
    result['all_reference_pages_covered'] = int(allrefs <= selected_pages)
    result['macro_page_coverage'] = (result['annual_page_coverage'] + result['law_page_coverage']) / 2
    # Answer points have role requirements but no exhaustive point-to-span qrels.
    points = release.points_for(q['question_id'])
    result['required_point_role_availability_proxy'] = np.mean([
        all(bool(refsets[r] & selected_pages) for r in point['required_evidence_roles'])
        for point in points]).item()
    texts_by_page = defaultdict(list)
    for c in selected:
        if source_hash(c):
            texts_by_page[page_key(c)].append(c['text'])
    shingle_fractions = []
    for ev in refs:
        reference = shingle(ev['exact_quote'])
        retrieved = set().union(*(shingle(text) for text in texts_by_page[ref_key(ev)]))
        shingle_fractions.append(len(reference & retrieved) / len(reference) if reference else 0)
    result['reference_quote_12char_shingle_coverage'] = float(np.mean(shingle_fractions))
    return result


METRICS = ['reference_tokens','selected_chunks','annual_chunks','regulation_chunks',
           'annual_fraction','has_both_roles','annual_page_coverage','law_page_coverage',
           'annual_any_reference_page','law_any_reference_page','both_reference_roles_available',
           'all_reference_pages_covered','macro_page_coverage',
           'required_point_role_availability_proxy','reference_quote_12char_shingle_coverage']


def summarize(rows):
    groups = defaultdict(list)
    for row in rows:
        groups[(row['strategy'], row['quota'], row['budget_tokens'], row['topic'])].append(row)
        groups[(row['strategy'], row['quota'], row['budget_tokens'], 'ALL')].append(row)
    out = []
    for (strategy, quota, cap, topic), group in sorted(groups.items()):
        item = dict(strategy=strategy, quota=quota, budget_tokens=cap, topic=topic,
                    n_questions=len(group), n_companies=len({r['stock_code'] for r in group}))
        for key in METRICS:
            values = np.asarray([r[key] for r in group])
            item[key + '_mean'] = float(values.mean())
            if key in ['reference_tokens','selected_chunks','annual_chunks','regulation_chunks']:
                item[key + '_median'] = float(np.median(values))
                item[key + '_min'] = int(values.min())
                item[key + '_max'] = int(values.max())
        out.append(item)
    return out


def paired_stats(rows):
    rng = np.random.default_rng(20261023)
    data = {(r['question_id'],r['strategy'],r['quota'],r['budget_tokens']):r for r in rows}
    question_ids = sorted({r['question_id'] for r in rows})
    companies = sorted({r['stock_code'] for r in rows})
    ci = []
    for quota in QUOTAS:
        for cap in CAPS:
            for metric in ['has_both_roles','annual_page_coverage','law_page_coverage',
                           'both_reference_roles_available','macro_page_coverage',
                           'reference_tokens','reference_quote_12char_shingle_coverage']:
                cluster = defaultdict(list)
                for qid in question_ids:
                    a, b = data[qid,'merged',quota,cap], data[qid,'dual',quota,cap]
                    cluster[a['stock_code']].append(b[metric]-a[metric])
                values = np.asarray([np.mean(cluster[c]) for c in companies])
                draws = rng.choice(values, size=(10000,len(values)), replace=True).mean(axis=1)
                low, high = np.quantile(draws,[.025,.975])
                ci.append(dict(quota=quota,budget_tokens=cap,metric=metric,
                    contrast='dual_minus_merged',company_clusters=len(values),n_questions=len(question_ids),
                    difference=float(values.mean()),ci95_low=float(low),ci95_high=float(high),
                    bootstrap_draws=10000,bootstrap_seed=20261023,
                    inference='posthoc_descriptive_company_cluster_percentile_bootstrap_no_multiplicity_claim'))
    return ci


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    plan_path = RUN/'execution_plan.json'
    plan = load(plan_path)
    prepared = RUN/'prepared'
    manifest_path = prepared/'comparison_manifest.json'
    manifest = load(manifest_path)
    assert sha(plan_path) == manifest['execution_plan_sha256']
    tokenizer_path = Path(plan['reference_tokenizer_file'])
    assert sha(tokenizer_path) == plan['reference_tokenizer_sha256']
    tokenizer = Tokenizer.from_file(str(tokenizer_path))
    tokenizer.no_padding(); tokenizer.no_truncation()
    count = lambda text: len(tokenizer.encode(text,add_special_tokens=False).ids)
    idx = Path(plan['index_dir'])
    assert sha(idx/'index_manifest.json') == plan['index_manifest_sha256']
    im = load(idx/'index_manifest.json')
    assert sha(idx/im['chunk_file']) == im['chunk_file_sha256']
    chunks = [json.loads(line) for line in (idx/im['chunk_file']).read_text(encoding='utf-8').splitlines() if line.strip()]
    by_id = {c['chunk_id']:c for c in chunks}
    # Only serialized chunks are required: vectors and neural model loading are unnecessary.
    release = load_page_reference_release(plan['reference_dir'],plan['reference_manifest_sha256'])
    input_files = [plan_path,manifest_path,idx/'index_manifest.json',idx/im['chunk_file'],tokenizer_path,
                   Path(plan['reference_dir'])/'release_manifest.json']
    rows, cache_rows, replay_checks = [], [], []
    for spec in manifest['question_files']:
        path = prepared/spec['path']
        assert sha(path) == spec['sha256']
        input_files.append(path)
        bundle = load(path); q = bundle['question']; qid = q['question_id']
        topic = qid.split('-2024-')[-1]
        for strategy in ['merged','dual']:
            original = bundle['contexts'][strategy]
            ids = original['retrieved_candidate_ids']
            assert len(ids) == 10 and len(ids) == len(set(ids))
            # Cached final-ranking scores are not needed for deterministic packing.
            hits = [(Chunk(**by_id[cid]),0.) for cid in ids]
            reconstructed = _pack_context(hits,count,6000)
            assert reconstructed['context'] == original['context'], (qid,strategy)
            assert reconstructed['reference_tokens'] == original['reference_tokens']
            assert [r['chunk_id'] for r in reconstructed['source_records']] == [r['chunk_id'] for r in original['source_records']]
            replay_checks.append(dict(question_id=qid,strategy=strategy,byte_identical_context=True,
                reference_tokens_match=True,source_ids_match=True,cached_candidates=len(ids)))
            for rank,cid in enumerate(ids,1):
                c = by_id[cid]
                cache_rows.append(dict(question_id=qid,stock_code=q['stock_code'],topic=topic,strategy=strategy,
                    rank=rank,chunk_id=cid,doc_id=c['doc_id'],corpus_type=c['meta']['corpus_type'],
                    source_sha256=source_hash(c),physical_pdf_page_1based=c['meta'].get('physical_pdf_page_1based')))
            for quota in QUOTAS:
                # dual ordering was frozen as alternating A1,R1,A2,R2,...;
                # taking first even quota implements symmetric quotas without reranking.
                for cap in CAPS:
                    context = _pack_context(hits[:quota],count,cap)
                    row = dict(question_id=qid,stock_code=q['stock_code'],company_name=q['company_name'],topic=topic,
                               dimension=q['dimension'],strategy=strategy,quota=quota,budget_tokens=cap,
                               retrieval_calls=0,neural_inference_calls=0)
                    row.update(diagnostics(context,q,release))
                    rows.append(row)
    summary = summarize(rows)
    paired = paired_stats(rows)
    eligible = [c for c in chunks if c['doc_id'] not in plan['excluded_superseded_doc_ids']]
    corpus = []
    for role in ['annual_report','regulation']:
        cs = [c for c in eligible if c['meta']['corpus_type']==role]
        corpus.append(dict(role=role,chunks=len(cs),unique_doc_ids=len({c['doc_id'] for c in cs}),
            unique_source_hashes=len({source_hash(c) for c in cs if source_hash(c)}),
            chunks_with_source_hash=sum(bool(source_hash(c)) for c in cs),
            chunks_with_physical_page=sum(bool(c['meta'].get('physical_pdf_page_1based')) for c in cs)))
    per_question = []
    for q in release.questions.values():
        annual=[c for c in eligible if c['meta']['corpus_type']=='annual_report' and c['meta'].get('stock_code')==q['stock_code'] and c['meta'].get('report_year')==q['report_year']]
        per_question.append(dict(question_id=q['question_id'],stock_code=q['stock_code'],topic=q['question_id'].split('-2024-')[-1],
            eligible_annual_chunks=len(annual),eligible_regulation_chunks=corpus[1]['chunks'],
            reference_annual_pages=len(q['reference_annual_evidence_ids']),reference_law_pages=len(q['reference_law_evidence_ids']),
            answer_points=len(release.points_for(q['question_id']))))
    write_csv(OUT/'replay_per_question.csv',rows)
    write_csv(OUT/'replay_summary.csv',summary)
    write_csv(OUT/'paired_company_bootstrap.csv',paired)
    write_csv(OUT/'cached_final_candidates.csv',cache_rows)
    write_csv(OUT/'corpus_scope.csv',corpus)
    write_csv(OUT/'question_scope.csv',per_question)
    write_json(OUT/'replay_summary.json',summary)
    write_json(OUT/'replay_verification.json',replay_checks)
    receipt = dict(schema_version='cached-final-ranking-replay-v1',created_at_utc=datetime.now(timezone.utc).isoformat(),
        purpose='Exploratory mechanism and sensitivity analysis; no end-to-end generation rerun.',
        questions=60,companies=20,topics=3,strategies=2,quotas=QUOTAS,token_budgets=CAPS,
        replay_contexts=len(rows),frozen_contexts_reproduced=len(replay_checks),bootstrap_draws=10000,bootstrap_seed=20261023,
        reference_level='human-adjudicated physical pages and answer-point role requirements; not exhaustive relevance qrels',
        reference_tokenizer='Qwen3-Embedding-0.6B frozen tokenizer; not provider usage tokens',
        selection='Frozen top-10 merged candidates vs frozen alternating top-5 annual/top-5 law candidates, whole-chunk skip-oversize packing.',
        quotas_policy='Fixed before replay: merged top 2/6/10; dual 1+1/3+3/5+5. No reference labels influence selection.',
        candidate_limitation='At 8k, only original final top-10 are available; no expanded candidate search and no reranking. Larger budget may plateau because candidate-limited.',
        quality_limit='Same source+page hit is not semantic support; role-availability proxy is not answer-point accuracy; text shingle coverage is lexical only.',
        neural_inference_calls=0,api_calls=0,device='CPU',python=sys.executable,
        index_total_chunks=len(chunks),eligible_corpus=corpus,
        inputs=[dict(path=str(p),sha256=sha(p)) for p in input_files],
        script=dict(path=str(Path(__file__).resolve()),sha256=sha(Path(__file__))))
    write_json(OUT/'retrieval_replay_receipt.json',receipt)
    print(json.dumps({k:receipt[k] for k in ['replay_contexts','frozen_contexts_reproduced','eligible_corpus']},ensure_ascii=False))
    print('BASELINE_TOP10_CAP6000')
    print(json.dumps([r for r in summary if r['quota']==10 and r['budget_tokens']==6000 and r['topic']=='ALL'],ensure_ascii=False))


if __name__ == '__main__':
    main()
