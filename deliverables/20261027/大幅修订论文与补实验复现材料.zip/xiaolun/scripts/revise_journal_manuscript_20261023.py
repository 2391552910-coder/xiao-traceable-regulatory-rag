"""Journal-style revision preserving all reported observations and the old draft."""
from pathlib import Path
from copy import deepcopy
from io import BytesIO
import hashlib, json, re
from docx import Document
from docx.shared import Cm, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'results/paper/journal_revision_20261023_01'
SOURCE = next((ROOT/'results/paper/draft_20261023_01').glob('*.docx'))
old = Document(SOURCE)
texts = [p.text for p in old.paragraphs]

def base(title):
    d=Document(); s=d.sections[0]
    s.page_width,s.page_height=Cm(21),Cm(29.7)
    s.top_margin=s.bottom_margin=Cm(2)
    s.left_margin=s.right_margin=Cm(2.1)
    s.header_distance=s.footer_distance=Cm(0.9)
    for name in ['Normal','Title','Subtitle','Heading 1','Heading 2','Heading 3','Caption']:
        st=d.styles[name]; st.font.name='Times New Roman'
        st._element.get_or_add_rPr().rFonts.set(qn('w:eastAsia'),'宋体')
        st.font.color.rgb=RGBColor(0,0,0)
    n=d.styles['Normal']; n.font.size=Pt(10.5)
    n.paragraph_format.line_spacing=1.18; n.paragraph_format.space_after=Pt(5)
    for name,size in [('Title',18),('Heading 1',13),('Heading 2',11),('Heading 3',10.5)]:
        st=d.styles[name]; st.font.size=Pt(size)
        st.paragraph_format.space_before=Pt(10 if name!='Title' else 0)
        st.paragraph_format.space_after=Pt(5)
        st.paragraph_format.keep_with_next=True
    for st in d.styles:
        if st.type==1:
            pp=st._element.find(qn('w:pPr'))
            if pp is not None:
                for el in list(pp):
                    if el.tag==qn('w:pBdr'): pp.remove(el)
    d.styles['Title'].paragraph_format.keep_with_next=False
    d.styles['Caption'].font.size=Pt(9)
    f=s.footer.paragraphs[0]; f.alignment=1
    fld=OxmlElement('w:fldSimple'); fld.set(qn('w:instr'),'PAGE'); f._p.append(fld)
    d.core_properties.title=title; d.core_properties.author=''
    d.core_properties.subject='中文研究修订稿 2026年10月23日'
    return d

def p(d,text,style=None):
    x=d.add_paragraph(text,style); x.paragraph_format.widow_control=True
    return x
def h(d,text,level=1): return d.add_heading(text,level)
def source_p(d,i): return p(d,texts[i])
def format_table(t):
    t.autofit=False
    if len(t.columns)==2:
        for row in t.rows:
            row.cells[0].width=Cm(3.5); row.cells[1].width=Cm(13.3)
        t.columns[0].width=Cm(3.5); t.columns[1].width=Cm(13.3)
    if len(t.columns)==3:
        widths=[3.5,3.5,9.8] if t.rows[0].cells[0].text=='实验' else ([1.2,3.2,12.4] if t.rows[0].cells[0].text=='优先级' else [5.6,5.6,5.6])
        for col,w in zip(t.columns,widths): col.width=Cm(w)
        for row in t.rows:
            for cell,w in zip(row.cells,widths): cell.width=Cm(w)
    for rowi,row in enumerate(t.rows):
        pr=row._tr.get_or_add_trPr(); pr.append(OxmlElement('w:cantSplit'))
        if rowi==0:
            rep=OxmlElement('w:tblHeader'); pr.append(rep)
        for cell in row.cells:
            tcpr=cell._tc.get_or_add_tcPr()
            borders=OxmlElement('w:tcBorders')
            for side in ['top','left','bottom','right']:
                e=OxmlElement('w:'+side); e.set(qn('w:val'),'single'); e.set(qn('w:sz'),'4'); e.set(qn('w:color'),'D9D9D9'); borders.append(e)
            tcpr.append(borders)
            mar=OxmlElement('w:tcMar')
            for side in ['top','left','bottom','right']:
                e=OxmlElement('w:'+side); e.set(qn('w:w'),'75'); e.set(qn('w:type'),'dxa'); mar.append(e)
            tcpr.append(mar)
            if rowi==0:
                sh=OxmlElement('w:shd'); sh.set(qn('w:fill'),'F0F0F0'); tcpr.append(sh)
            for para in cell.paragraphs:
                if len(t.rows)<=6: para.paragraph_format.keep_with_next=rowi<len(t.rows)-1
                para.paragraph_format.space_after=Pt(2); para.paragraph_format.space_before=Pt(2)
                para.paragraph_format.line_spacing=1.05
                for run in para.runs:
                    run.font.size=Pt(9); run.font.bold=rowi==0
                    run.font.color.rgb=RGBColor(0,0,0)
    return t
def table(d,headers,rows):
    t=d.add_table(rows=1,cols=len(headers)); t.style='Table Grid'
    for c,v in zip(t.rows[0].cells,headers): c.text=str(v)
    for row in rows:
        for c,v in zip(t.add_row().cells,row): c.text=str(v)
    return format_table(t)
def oldtable(d,i,caption):
    cp=p(d,caption,'Caption'); cp.paragraph_format.keep_with_next=True
    el=deepcopy(old.tables[i]._element); d._body._body.insert(len(d._body._body)-1,el)
    format_table(d.tables[-1])
    if i==1:
        d.tables[-1].rows[-1].cells[-1].text='固定检索revision、生成参数和调用清单'
        format_table(d.tables[-1])

def manuscript():
    title='年报与法规双源检索对上市公司评价问答质量的影响'
    d=base(title); p(d,title,'Title')
    p(d,'Dual-source Retrieval over Annual Reports and Regulations for Listed-company Evaluation')
    h(d,'摘要')
    p(d,'上市公司评价问答需要同时核对公司披露事实与规范依据，合并检索可能使一类证据挤占有限上下文。本文构建保留文件身份和原文坐标的双源检索增强生成流程，并以受控实验分别考察来源分离与来源角色提示的作用。评测覆盖20家公司2024年年报的60个问题，主对照、消融、来源缺失及同系列模型版本比较共计划400条回答，其中386条有效输出经两位人员逐项核对原文评分。以四项评分的双人等权均分构成0至8分探索性指标，按公司聚类进行配对bootstrap分析。已观测配对中，双路检索较合并检索提高0.250分，点对点95%区间为[0.167, 0.333]；相同证据下来源角色提示的差值为−0.008分，区间跨0。删除年报与删除法规分别下降0.900和0.650分。完整检索配置未普遍优于简化配置。结果表明，本轮任务中的两类来源具有互补价值，而额外提示约束与检索复杂度的收益需要分别检验。该结论限于当前语料、评分量表和已观测配对，不代表法规时点适用性或公司真实治理质量得到验证。')
    source_p(d,4)
    h(d,'Abstract')
    p(d,'Listed-company evaluation requires both disclosed company facts and regulatory evidence. We study whether separating these sources improves retrieval-augmented question answering under a fixed context cap. A traceable pipeline preserves document identities and source coordinates. Controlled comparisons distinguish merged retrieval, dual-source retrieval, and source-role prompting with identical retrieved evidence. The evaluation comprises 60 questions about 20 companies’ annual reports for 2024. Of 400 planned responses across main comparisons, ablations, source-removal tests, and a same-family model-version comparison, 386 valid outputs were independently scored by two reviewers. We average four ordinal dimensions across reviewers to form an exploratory 0–8 quality score and use company-clustered paired bootstrap intervals. On observed pairs, dual-source retrieval improves the company-macro score by 0.250 points over merged retrieval, with a pointwise 95% interval of [0.167, 0.333]. Source-role prompting adds no stable gain when evidence is held constant. Removing annual reports or regulations reduces scores by 0.900 and 0.650 points, respectively. The full retrieval configuration does not consistently outperform simpler variants. These exploratory findings support source complementarity within the evaluated task, while leaving temporal legal applicability, broader generalization, and generation variability unresolved.')
    p(d,'Keywords: retrieval-augmented generation; annual reports; regulatory evidence; provenance; human evaluation')
    h(d,'1 引言')
    p(d,'上市公司评价中的一个基本困难是，企业披露与规范要求分布在不同文件中。例如，回答审计委员会履职问题，既需要定位公司在年报中的相关披露，也需要核对规范文本中的要求。流畅的回答如果遗漏任一类依据，仍可能无法支撑评价；即使引用文件确实存在，文件中的文字也未必支持对应论断。本文研究的是基于给定资料的评价问答，而非直接测量公司治理水平。')
    p(d,'RAG通过检索外部文本支撑生成[1]，但通用相关性排序不保证两类来源均被纳入上下文。双源材料可以采用合并候选池，也可以分别召回后共同输入生成器。与此同时，提示模型区分事实与规范，可能改善证据使用，也可能只改变表述。因此，来源分离和来源角色提示必须在不同的受控比较中检验，不能把整个流水线的变化归因于某一模块。')
    p(d,'本文围绕三个研究问题展开：RQ1，在固定上下文上限下，双路检索相对合并检索是否改善回答质量；RQ2，在证据完全相同的条件下，增加来源角色约束是否带来额外收益；RQ3，当检索配置简化、删除一类证据或更换同系列服务版本时，观察到的差异是否稳定。')
    p(d,'本文的工作是构建保留来源身份与坐标的双源原型，将检索组织与生成提示拆分为可比较条件，并报告双人评分、公司层面的配对差异及失败边界。当前证据支持双路检索和来源互补的任务内价值，但不支持来源角色提示的稳定额外增益，也不支持完整配置具有普遍优势。研究定位为探索性实证比较；本文不将组件组合本身作为新的通用算法。')
    h(d,'2 背景与相关工作')
    h(d,'2.1 领域知识增强与检索组织',2)
    p(d,'稠密检索[2]和统一的嵌入与重排模型[3]为文档召回提供基础。Siddharth与Luo研究从工程文档中提取显式事实用于RAG[6]，Yang等综述了语言模型与知识方法的结合[7]。这些工作表明，外部知识的表示与使用应作为独立问题处理。与显式三元组知识库不同，本文直接面向年报与法规文件，主要检验有限上下文内不同来源的组织方式。')
    p(d,'Alier等在Information Sciences中针对教育语料中的缩写检索困难，分别设置查询时增强与入库时增强，并分析组件效果、误差和成本[8]。本文借鉴其分离组件作用的实验逻辑，但不使用其缩写本体或检索增强算法，也不将其结果直接推广到公司评价。本文的领域因素是披露证据与规范证据承担不同角色。')
    h(d,'2.2 引用支持与法律协作',2)
    p(d,'ALCE将答案质量与引用质量分别评价[4]，说明可打开的来源链接并不等同于语义支持。CoLE以法律专家分工为启发组织提示流程[9]；MADKE通过共享检索知识支持多智能体辩论[10]。这些研究与本文的证据使用问题相关，但其模块、模型和任务条件不同，不能作为本文已实现法律专家协作或多智能体辩论的依据。')
    p(d,'本文采用固定检索与提示编排，并未实现自主规划、动态工具选择或多智能体交互。来源角色提示只是生成条件之一。与协作式或迭代式方法的性能比较仍待开展，不能凭借模块名称、多个检索分支或两名评分人员将现有系统描述为Agent系统。')
    h(d,'3 双源检索与可追溯生成方法')
    h(d,'3.1 任务定义与输出',2)
    p(d,'令问题输入为x=(c,y,q)，其中c为公司标识，y为报告年度，q为评价问题。给定年报集合D_A与法规集合D_R，系统输出回答a及其论断对应的证据编号、来源位置和证据不足说明。事实性陈述主要依据D_A，规范性陈述主要依据D_R，比较性评价通常需要两类来源共同支撑。报告年度仅用于文档范围约束，不替代事项日期。')
    h(d,'3.2 文档登记与检索作用域',2)
    source_p(d,10); source_p(d,11)
    p(d,'用R_A(x)和R_R(x)表示两个作用域内的候选结果，用Pack表示按预算组装上下文。G1从共同候选池选择证据；G2分别召回后组装；G3复用G2的实际上下文。形式上：')
    p(d,'E₁ = Pack(Retrieve(x, D_A ∪ D_R));   E₂ = Pack(R_A(x), R_R(x));   E₃ = E₂。')
    p(d,'该表达描述现有流程的比较关系，不引入新的训练目标。三条件均保留来源标识；G3相对于G2只改变生成提示。两侧各最多5条、总计6000参考分词器token构成上限，实际长度和服务端计算量可能不同。')
    oldtable(d,0,'表1 主对照条件及其控制关系')
    h(d,'3.3 来源角色约束与核验边界',2)
    source_p(d,12); source_p(d,13)
    p(d,'算法流程为：登记文档及来源坐标；按公司与年度限定年报作用域；分别召回和重排；按条件组装证据并保存实际提示；生成回答和引用；执行结构检查，再在离线评测中由人员核对原文。结构有效、来源可回放、论断语义支持与法规适用性属于不同层次，不能相互替代。')
    h(d,'4 实验设计')
    h(d,'4.1 语料与评测问题',2)
    source_p(d,17); source_p(d,18)
    oldtable(d,1,'表2 本轮评测的数据与冻结对象')
    p(d,'表2中的既有复核A1、A2用于题目与原件身份判断。输出评分另由两位人员逐条核对原文并确认386条回答的最终评分。两套过程分别记录，不能将输出均分称为金标裁定。原始判断、分歧及过程更正均保留。')
    source_p(d,20); source_p(d,21)
    h(d,'4.2 实现与比较条件',2)
    source_p(d,24); source_p(d,25); source_p(d,26); source_p(d,27)
    p(d,'本地检索模型运行在GTX 1660 Ti上，使用CUDA、float16和batch size 1；生成通过远程API完成。硬件配置用于说明复现环境，不作为服务端生成效率的解释。检索模型revision见附录A。')
    h(d,'4.3 人员评分与统计方法',2)
    source_p(d,28)
    p(d,'设sᵢᵣⱼ为回答i、评分者r、维度j的分数，则Qᵢ=(1/2)ΣᵣΣⱼsᵢᵣⱼ，Qᵢ∈[0,8]。四个维度为公司事实、法规依据、引用支持和不确定性处理。若任一评分者的任一维度为U，则该回答总分未知。本轮没有U。该均分仅是分析用复合指标，不替代逐维度判断。')
    source_p(d,29)
    p(d,'等权均分与分别按评分者统计的分析方案于2026年10月23日在评分可见后确定，因此属于探索性分析。所有比较先匹配相同题目；不同子集上的条件均分仅作描述，不构成配对效应。')
    h(d,'5 实验结果')
    h(d,'5.1 运行覆盖率',2)
    oldtable(d,2,'表3 主对照与扩展实验的结构有效输出及失败记录')
    source_p(d,32); source_p(d,33)
    p(d,'主对照恢复视图178条、消融109条、来源缺失40条及第二版本59条共形成386条评分输出。相对400个计划单元，14个单元无结构有效回答。请求失败不记为质量0分，首轮失败与恢复记录也不合并抹除。')
    h(d,'5.2 质量分布与评分者一致性',2)
    source_p(d,34)
    oldtable(d,3,'表4 各条件的可用回答及公司宏均分 量表范围0至8')
    p(d,texts[37].replace('表1','表4'))
    oldtable(d,4,'表5 四个维度的评分一致性 共386条回答')
    p(d,texts[41].replace('表2','表5'))
    h(d,'5.3 双路检索与来源角色提示',2)
    oldtable(d,5,'表6 主对照与消融的已观测配对差异 95%区间为点对点公司聚类bootstrap区间')
    source_p(d,45)
    h(d,'5.4 检索简化与来源缺失',2)
    source_p(d,46); source_p(d,48)
    h(d,'5.5 同系列版本比较',2)
    oldtable(d,6,'表7 同系列服务版本的配对差异 K2.8减K3')
    p(d,texts[50].replace('表4','表7'))
    # Extract the existing result image without recomputing or redrawing observations.
    for shape in old.inline_shapes:
        rid=shape._inline.graphic.graphicData.pic.blipFill.blip.embed
        blob=old.part.related_parts[rid].blob
        img=OUT/'qa'/'preserved_effect_plot.png'; img.parent.mkdir(exist_ok=True); img.write_bytes(blob)
        d.add_picture(BytesIO(blob),width=Cm(16.6))
    source_p(d,52)
    h(d,'6 讨论与有效性限制')
    h(d,'6.1 来源分离的收益与方法边界',2)
    p(d,'G2相对G1的正向差异与来源缺失后的降分共同支持两类资料的互补价值，但两者回答的问题不同：前者改变检索组织，后者从已有上下文中删除证据。仅凭总质量分还不能说明收益来自参考要点召回率、来源平衡还是答案组织，需补充检索侧和逐论断指标才能定位机制。')
    p(d,'G3未稳定优于G2，说明明确的来源角色提示在当前证据和量表下没有显示可辨别的额外收益。高分集中、生成采样和量表分辨率都可能影响检测能力；这些是待检验解释，不能改写为已证实的原因。重排与稠密融合也未显示普遍收益，现有结果不足以据此推荐更复杂的系统配置。')
    h(d,'6.2 内部与外部有效性',2)
    source_p(d,35)
    p(d,'尺度的高分集中还限制了对引用质量的判断：引用支持97.67%的精确一致率伴随κ=0，不能据此宣称人员评分高度可靠。法规依据仅55.96%精确一致，更需要区分法规检索相关、原文支持和事项时点适用。主实验、消融和模型版本比较还受到缺失输出与服务参数差异影响。')
    h(d,'6.3 后续验证方向',2)
    p(d,'后续首先应在现有冻结结果上补充可回放的检索诊断，分别统计两类来源及其联合覆盖；对于尚无穷尽片段标注的部分，不直接报告标准片段级Recall或nDCG。随后在新增并预先固定的问题上，比较普通RAG、双路检索与预算匹配的查询改写或协作核验方法，并分开报告内容质量、调用成本和延迟。重复生成、其他模型族及跨年度公司样本能够扩展结论范围，但须以新实验结果为依据。')
    h(d,'7 结论')
    source_p(d,54)
    h(d,'数据与代码可用性')
    p(d,'研究的题目、参考证据、运行记录和人员评分保存在项目复现材料中。论文公开仓库地址及可公开的数据范围尚未确定，不在本文虚构公开链接。原始年报与法规文件应保留来源与版本记录，人员信息在共享前按实际授权处理。')
    h(d,'参考文献')
    for i in range(56,61): source_p(d,i)
    refs=[
    '[6] L. Siddharth, J. Luo, Retrieval augmented generation using engineering design knowledge, Knowledge-Based Systems 303 (2024) 112410. https://doi.org/10.1016/j.knosys.2024.112410.',
    '[7] W. Yang, L. Some, M. Bain, B. Kang, A comprehensive survey on integrating large language models with knowledge-based methods, Knowledge-Based Systems 318 (2025) 113503. https://doi.org/10.1016/j.knosys.2025.113503.',
    '[8] M. Alier, F.J. García-Peñalvo, M.J. Casañ, J. Pereira, A. Granados, Closing the acronym gap in educational retrieval with ontology-guided augmentation, Information Sciences 740 (2026) 123181. https://doi.org/10.1016/j.ins.2026.123181.',
    '[9] B. Li, S. Fan, S. Zhu, L. Wen, CoLE: A collaborative legal expert prompting framework for large language models in law, Knowledge-Based Systems 311 (2025) 113052. https://doi.org/10.1016/j.knosys.2025.113052.',
    '[10] H. Wang, X. Du, W. Yu, Q. Chen, K. Zhu, Z. Chu, L. Yan, Y. Guan, Learning to break: Knowledge-enhanced reasoning in multi-agent debate system, Neurocomputing 618 (2025) 129063. https://doi.org/10.1016/j.neucom.2024.129063.'
    ]
    for s in refs: p(d,s)
    h(d,'附录A 复现记录与修订范围')
    source_p(d,62)
    p(d,'Embedding revision：97b0c614be4d77ee51c0cef4e5f07c00f9eb65b3。Reranker revision：e61197ed45024b0ed8a2d74b80b4d909f1255473。')
    p(d,'本稿根据2026年10月23日双人评分结果稿重新组织论述和版式，所有结果表与效应图沿用原稿，不新增实验观测，不改写评分、不填补失败质量分。主参照为文献[8]的单栏正文与引言、相关工作、方法、实验、讨论、结论结构。采用中文可编辑研究稿，不复制出版社刊头、DOI或录用日期。作者、单位、基金、利益冲突、CRediT及AI辅助写作披露须由作者按真实情况在投稿版中补齐。')
    # Number references in their order of first citation.
    mapping={1:1,2:2,3:3,6:4,7:5,8:6,4:7,9:8,10:9,5:10}
    for para in d.paragraphs:
        if re.search(r'\[\d+\]',para.text):
            para.text=re.sub(r'\[(\d+)\]',lambda m:'['+str(mapping[int(m.group(1))])+']',para.text)
    refs_p=[para for para in d.paragraphs if re.match(r'^\[\d+\]',para.text)]
    anchor=refs_p[0]._p
    for para in sorted(refs_p,key=lambda v:int(re.match(r'^\[(\d+)\]',v.text).group(1))):
        anchor.addprevious(deepcopy(para._p))
    for para in refs_p: para._p.getparent().remove(para._p)
    path=OUT/'年报与法规双源RAG_期刊结构修订稿.docx'; d.save(path)
    return path

PAPERS=[
 dict(id='KBS01',journal='Knowledge-Based Systems',title='Retrieval augmented generation using engineering design knowledge',authors='L. Siddharth; Jianxi Luo',year='2024',volume='303',article='112410',doi='10.1016/j.knosys.2024.112410',url='https://arxiv.org/pdf/2307.06985',file='KBS_01_engineering_author.pdf',version='作者公开稿 arXiv 2307.06985；不等同于出版社定稿',fit='较高：领域文档、显式知识与RAG；其事实库和本文直接文档检索不同'),
 dict(id='KBS02',journal='Knowledge-Based Systems',title='A comprehensive survey on integrating large language models with knowledge-based methods',authors='Wenli Yang; Lilian Some; Michael Bain; Byeong Kang',year='2025',volume='318',article='113503',doi='10.1016/j.knosys.2025.113503',url='https://arxiv.org/pdf/2501.13947',file='KBS_02_survey_author.pdf',version='作者公开稿 arXiv 2501.13947；不等同于出版社定稿',fit='中等：知识增强、RAG与相关技术定位；属于综述，不作为实验论文的主排版模板'),
 dict(id='INS01',journal='Information Sciences',title='Closing the acronym gap in educational retrieval with ontology-guided augmentation',authors='Marc Alier; Francisco José García-Peñalvo; María José Casañ; Juanan Pereira; Arnau Granados',year='2026',volume='740',article='123181',doi='10.1016/j.ins.2026.123181',url='https://upcommons.upc.edu/server/api/core/bitstreams/4aa740f4-cc38-42b0-87ba-53cb16043c02/content',file='INS_01_acronym_published.pdf',version='机构仓储出版社版 CC BY 4.0；21页',fit='高：领域RAG、组件受控比较、检索指标、误差与成本分析；作为已取得全文中的主结构和版式参照'),
 dict(id='INS02',journal='Information Sciences',title='An empirical study of retrieval-augmented diffusion language models for generative commonsense reasoning',authors='Yubo Fang; Hai-Tao Yu; Hideo Joho; Sumio Fujita; Yan Ge; Chao Lei',year='2027',volume='761',article='124147',doi='10.1016/j.ins.2026.124147',url='https://www.sciencedirect.com/science/article/pii/S0020025526010789',file=None,version='已检索到期刊与作者机构记录；卷期日期为2027-02-05。作者团队2026年9月宣布录用；精确在线日期未核实。全文下载受限',fit='中等：同骨干有无检索的配对设计可借鉴；常识生成与双源公司评价任务不同'),
 dict(id='NEU01',journal='Neurocomputing',title='Adaptive iterative retrieval for enhanced retrieval-augmented generation',authors='Wenhan Han; Xiao Xiao; Yaohang Li; Jun Wang; Mykola Pechenizkiy; Meng Fang',year='2026',volume='666',article='132272',doi='10.1016/j.neucom.2025.132272',url='https://www.sciencedirect.com/science/article/pii/S0925231225029443',file=None,version='期刊开放获取标识已核实；本次出版社下载403，全文API401；尚未取得本地全文',fit='高：迭代检索和检索器—生成器协同，适合后续迭代检索基线；不能混同于同名AirRAG arXiv 2501.10053'),
 dict(id='NEU02',journal='Neurocomputing',title='Learning to break: Knowledge-enhanced reasoning in multi-agent debate system',authors='Haotian Wang; Xiyuan Du; Weijiang Yu; Qianglong Chen; Kun Zhu; Zheng Chu; Lian Yan; Yi Guan',year='2025',volume='618',article='129063',doi='10.1016/j.neucom.2024.129063',url='https://export.arxiv.org/pdf/2312.04854',file='NEU_02_MADKE_author.pdf',version='作者公开稿 arXiv 2312.04854 v2；18页；与2025年期刊记录分别保存',fit='高：共享外部知识与多智能体辩论；适合Agent对照，不可据此宣称本项目已有多智能体实现')
]

def review_report():
    d=base('双源RAG期刊文献筛选与补实验建议')
    p(d,'双源RAG期刊文献筛选与补实验建议','Title')
    p(d,'检索与修订日期 2026年10月23日')
    p(d,'已为三个指定期刊各筛选两篇，共六篇。其中四篇已下载并验证可解析的PDF全文，两篇已核实题录但本次全文获取受访问限制。原稿和历史运行未修改。新增中文修订稿采用已取得全文中最适合受控实证叙事的INS01作为主参照；该选择是结构和版式判断，并非认定其教育任务与本项目完全相同。')
    h(d,'1 文献选择与文件状态')
    table(d,['编号','期刊','本地全文','用途'],[[x['id'],x['journal'],'已下载' if x['file'] else '待获取',x['fit'].split('：')[0]] for x in PAPERS])
    p(d,'用户给定的中科院分区仅作为选刊范围，本次未通过分区表数据库核验其具体年度与学科口径，不将其写成已核实的投稿事实。INS02的卷期年份为2027，DOI中包含2026不等于卷期年份；它作为2026年已录用并已有期刊页面的前沿补充条目单独说明。')
    for x in PAPERS:
        h(d,x['id']+' '+x['title'],2)
        p(d,x['authors']+'. '+x['journal']+' '+x['volume']+' ('+x['year']+') '+x['article']+'.')
        p(d,'DOI：https://doi.org/'+x['doi'])
        p(d,'获取地址：'+x['url'])
        p(d,'版本与状态：'+x['version'])
        p(d,'与本项目的关系：'+x['fit'])
        if x['file']: p(d,'本地文件：literature/'+x['file'])
    h(d,'2 重点阅读与借鉴边界')
    h(d,'2.1 主参照 INS01',2)
    p(d,'该文先展示领域检索失败，再分别介绍查询增强与入库增强，将方法配置、检索评价、组件作用和部署成本连起来。其正文为单栏，章节顺序为引言、背景与相关工作、方法、实验、讨论、结论，另列数据与代码可用性。实验部分包含数据与任务、统计方法、基线、结果、错误分析及成本。适合借鉴的是可检验问题与实验的对应关系，而非复制缩写本体或照搬其提升幅度。')
    p(d,'新稿据此拆开原稿合并的引言与相关工作；增加RQ1至RQ3；区分检索组织与来源角色提示；将运行覆盖率、评分一致性、配对结果及讨论分节。保留原7张表的数据、原效应图、均分定义、缺失界和探索性边界。版式使用A4单栏、宋体中文和Times New Roman英文，正文10.5磅，嵌入可编辑表格和页码；不复制期刊商标、卷期刊头或出版身份。')
    h(d,'2.2 领域知识与Agent相关工作',2)
    p(d,'KBS01提供了显式领域事实如何进入生成过程的案例，适合说明知识表示的选择；KBS02用于梳理知识增强的研究背景。NEU02的关键是多个智能体借助共享检索知识进行辩论，它与固定双路检索的区别应在文中明确。更贴近法律应用的补充条目是CoLE，DOI为10.1016/j.knosys.2025.113052，KBS 311 (2025) 113052；作者代码仓库为https://github.com/liboaccn/cole。该文已核实题录和摘要，尚未下载全文，不计入四篇下载数。')
    p(d,'NEU01可启发迭代检索基线，但其完整训练与偏好数据流程不能被简单提示改写替代。INS02强调同骨干下比较检索增强效果，适合提醒模型间比较要控制条件。上述未取得全文的条目只能依据已核实摘要与公开节选提出阅读方向，不写成完成全文精读。')
    h(d,'3 当前稿件最需要补强的证据')
    p(d,'现有结果已经能够形成一篇探索性实证稿，关键短板是机制与测量，而非缺少复杂模块。G2优于G1的观察尚不能确定来自哪一类证据覆盖；G3对G2的增益接近0；BM25与去重排结果并未支持完整配置普遍更好。后续研究应解释这些现象，避免只增加Agent名称或只挑选有利比较。')
    table(d,['优先级','补充内容','建议设计与产出'],[
      ['P0','现有输出审计','复核400单元与386有效输出映射、失败类别、配对覆盖；保持原结果与新结果分开。优先复用现有日志，无需先重跑生成。'],
      ['P0','检索机制诊断','对60题分别统计年报参考要点、法规参考要点和双源联合覆盖；记录真实上下文token及来源占比。现有标签非穷尽片段qrels，页命中须标为定位代理，不能冒称片段Recall。'],
      ['P0','引用与法规评分诊断','先分析232个分歧项及原文说明；分别汇总四项分数、天花板比例和法规错误类型。拟新增逐论断引用审计时先定协议，按必要来源核查，不默认全量重新评分。'],
      ['P1','重复生成','建议固定预选20题、G1/G2/G3、每条件新增3次，共180次调用；若扩至60题则540次。冻结请求参数与时点，按公司和重复轮次报告变化。'],
      ['P1','上下文预算与简单基线','建议20题×3种预算×G1/G2，共120次；例如3000/6000/9000参考token，同时报告实际token与延迟。加入无检索基线需另定20次调用，不能从来源缺失实验替代推算。'],
      ['P1','最小Agent比较','先实现可复现的单模型查询改写或核验回路，与直接双源及等调用数单智能体自检比较；各20题共60条最终回答，内部调用数另计。固定总token、轮数、工具权限并记录停止原因。'],
      ['P2','跨模型族与外部样本','新增独立模型族、未见公司或年度，分别固定协议；避免将K2.8/K3比较称为跨族泛化。新增样本规模以语料完整性和可评分预算确定。'],
      ['P2','时间适用性','构建事项发生日期、规范生效与失效日期及版本证据齐备的子集；单列未知和歧义，评价错版本、证据不足与拒答。不能仅凭报告年度确定适用法规。']
    ])
    p(d,'表中数量是建议的计划调用规模，不代表已执行实验或已产生结果。各方案可以分阶段开展，不必一次全部运行。新增API成本应先按实际服务价格与预算估算；本次未调用生成接口。')
    h(d,'4 结果表与案例的后续组织')
    p(d,'建议补成一张检索侧联合覆盖表、一张逐维度质量表、一张预算—质量—成本表，以及一组固定问题的完整证据案例。案例至少覆盖双路成功、角色提示无收益、重排失败、缺法规后合理保留未知等现象。案例必须来自已保存回答和原文，标注选择规则，不能将演示文本伪装为真实运行。')
    p(d,'若加入Agent，应把“是否重新检索”“是否核验引用”“是否有多智能体通信”分别消融。给多个模型相同证据不自动说明检索改进；增加调用预算后的收益也不能全部归于协作机制。与NEU02等方法比较时，需要说明是否忠实复现或仅为启发式适配。')
    h(d,'5 投稿前需要作者补齐的内容')
    p(d,'当前交付为中文结构修订稿，包含英文题名与摘要，尚不是英文投稿终稿。作者、单位、通讯信息、基金、CRediT、利益冲突和AI辅助写作披露均需按真实情况填写。官方作者指南页面本次访问403，不能声称已逐项完成当前期刊格式合规；确定目标期刊后，应再次核对最新作者指南，再完成英文全文、Highlights及必要声明。')
    p(d,'结构与版式模仿不等于复制文章表述。新稿相关工作为独立概述，不移植他文图表、数据和结论。未取得的两篇全文保留出版社链接与下载状态；如后续通过机构订阅或作者合法提供的全文取得，可更新manifest，不用摘要页或元数据XML充数。')
    h(d,'6 来源与复现文件')
    for u in ['https://www.sciencedirect.com/science/article/pii/S095070512401044X','https://www.sciencedirect.com/science/article/pii/S0950705125005490','https://www.sciencedirect.com/science/article/pii/S002002552600112X','https://www.sciencedirect.com/science/article/pii/S0020025526010789','https://www.sciencedirect.com/science/article/pii/S0925231225029443','https://www.sciencedirect.com/science/article/pii/S0925231224018344','https://ir-tsukuba.github.io/','https://www.elsevier.support/publishing/answer/how-do-i-include-highlights-with-my-manuscript']:
        p(d,u)
    p(d,'literature_manifest.json记录六篇题录、获取状态、PDF页数和SHA256；references.bib提供六篇期刊题录。qa_native目录保存只读原生导出及逐页排版检查材料。修订脚本保存在项目scripts目录中。')
    path=OUT/'文献筛选与补实验建议.docx'; d.save(path)
    return path

def manifest():
    from pypdf import PdfReader
    records=[]
    bib=[]
    for x in PAPERS:
        r=dict(x); r['status']='downloaded' if x['file'] else 'fulltext_unavailable'
        if x['file']:
            f=OUT/'literature'/x['file']; r['bytes']=f.stat().st_size
            r['sha256']=hashlib.sha256(f.read_bytes()).hexdigest(); r['pages']=len(PdfReader(f).pages)
            assert f.read_bytes()[:5]==b'%PDF-'
        records.append(r)
        bib.append('@article{'+x['id']+',\n  title={'+x['title']+'},\n  author={'+x['authors'].replace(';',' and')+'},\n  journal={'+x['journal']+'},\n  year={'+x['year']+'},\n  volume={'+x['volume']+'},\n  pages={'+x['article']+'},\n  doi={'+x['doi']+'}\n}')
    (OUT/'literature_manifest.json').write_text(json.dumps({'checked_date':'2026-10-23','papers':records,'selected_count':6,'downloaded_count':4,'source_manuscript_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest()},ensure_ascii=False,indent=2),encoding='utf-8')
    (OUT/'references.bib').write_text('\n\n'.join(bib),encoding='utf-8')

if __name__=='__main__':
    OUT.mkdir(exist_ok=True,parents=True)
    print(manuscript())
    print(review_report())
    manifest()
