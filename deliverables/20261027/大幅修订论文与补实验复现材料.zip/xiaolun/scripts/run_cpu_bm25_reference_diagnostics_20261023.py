"""Fresh BM25 CPU retrieval baseline on frozen public questions and index.

No neural/LLM calls. Global BM25 fit mirrors the existing hybrid component;
candidate scopes, role quotas and packing match the frozen retrieval comparison.
Reference labels are accessed for diagnostics only, after ranked IDs are fixed.
"""
from __future__ import annotations
import importlib.metadata
import json
import platform
import sys
import time
from collections import Counter
from datetime import datetime,timezone
from pathlib import Path
import numpy as np
from tokenizers import Tokenizer

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from scripts.replay_cached_retrieval_diagnostics_20261023 import RUN,OUT,CAPS,sha,load,write_json,write_csv,diagnostics,summarize
from src.data.clause_splitter import Chunk
from src.data.page_reference_release import load_page_reference_release
from src.generation.comparison import _pack_context
from src.retrieval.bm25 import BM25Retriever,_HAS_JIEBA


def main():
    out=OUT/'bm25_fresh';out.mkdir(parents=True,exist_ok=True)
    plan=load(RUN/'execution_plan.json');idx=Path(plan['index_dir']);im=load(idx/'index_manifest.json')
    assert sha(idx/'index_manifest.json')==plan['index_manifest_sha256']
    assert sha(idx/im['chunk_file'])==im['chunk_file_sha256']
    assert sha(plan['questions_file'])==plan['questions_sha256']
    assert sha(plan['reference_tokenizer_file'])==plan['reference_tokenizer_sha256']
    chunks=[Chunk(**json.loads(line)) for line in (idx/im['chunk_file']).read_text(encoding='utf-8').splitlines() if line.strip()]
    questions=[json.loads(line) for line in Path(plan['questions_file']).read_text(encoding='utf-8').splitlines() if line.strip()]
    token=Tokenizer.from_file(plan['reference_tokenizer_file']);token.no_padding();token.no_truncation()
    count=lambda text:len(token.encode(text,add_special_tokens=False).ids)
    # Baseline analysis plan is saved before scoring or reading reference labels.
    analysis_plan=dict(status='fixed_before_baseline_search',created_at_utc=datetime.now(timezone.utc).isoformat(),
        method='BM25',k1=1.5,b=.75,fit_scope='all19367 frozen index chunks, matching hybrid BM25 global IDF',
        search_scope='annual company+2024 and all5994 eligible regulations; exclude DOC004/DOC122/DOC343 legacy copies',
        strategies=dict(merged='global top10',dual='top5annual+top5law alternating'),
        query='unchanged frozen public query, no expansion or reference labels',token_budgets=CAPS,
        tokenizer='jieba' if _HAS_JIEBA else 'character_bigrams_fallback',
        inference='descriptive posthoc reference-page diagnostics; no end-to-end answer or relevance superiority claim')
    write_json(out/'analysis_plan.json',analysis_plan)
    start=time.perf_counter();retriever=BM25Retriever(chunks,k1=1.5,b=.75);fit_time=time.perf_counter()-start
    print(json.dumps({'stage':'BM25_fitted','seconds':fit_time,'chunks':len(chunks)}),flush=True)
    excluded=set(plan['excluded_superseded_doc_ids'])
    regs={c.chunk_id for c in chunks if c.meta['corpus_type']=='regulation' and c.doc_id not in excluded}
    ranks=[];contexts=[];timings=[]
    for qi,q in enumerate(questions,1):
        annual={c.chunk_id for c in chunks if c.meta['corpus_type']=='annual_report' and c.meta.get('stock_code')==q['stock_code'] and c.meta.get('report_year')==q['report_year']}
        allowed=regs|annual
        t=time.perf_counter();allhits=retriever.search(q['query'],top_k=len(allowed),candidate_ids=allowed);elapsed=time.perf_counter()-t
        ahits=[h for h in allhits if h[0].chunk_id in annual][:5];rhits=[h for h in allhits if h[0].chunk_id in regs][:5]
        alternating=[h for pair in zip(ahits,rhits) for h in pair]
        assert len(ahits)==len(rhits)==5
        timings.append(dict(question_id=q['question_id'],search_elapsed_seconds=elapsed,eligible_chunks=len(allowed),positive_scoring_chunks=len(allhits)))
        for strategy,hits in [('merged',allhits[:10]),('dual',alternating)]:
            assert len(hits)==10
            for ri,(c,score) in enumerate(hits,1):
                ranks.append(dict(question_id=q['question_id'],strategy=strategy,rank=ri,chunk_id=c.chunk_id,score=float(score),role=c.meta['corpus_type']))
            for cap in CAPS:
                contexts.append(dict(q=q,strategy=strategy,cap=cap,context=_pack_context(hits,count,cap)))
        if qi%10==0:print(json.dumps({'stage':'BM25_search','questions_completed':qi}),flush=True)
    # Persist ranking IDs before reading page labels, establishing selection did not use them.
    write_csv(out/'ranking_ids.csv',ranks)
    ranking_hash=sha(out/'ranking_ids.csv')
    release=load_page_reference_release(plan['reference_dir'],plan['reference_manifest_sha256'])
    rows=[]
    for item in contexts:
        q=item['q'];row=dict(question_id=q['question_id'],stock_code=q['stock_code'],company_name=q['company_name'],
            topic=q['question_id'].split('-2024-')[-1],dimension=q['dimension'],strategy=item['strategy'],quota=10,
            budget_tokens=item['cap'],method='BM25_fresh_CPU',retrieval_calls=1,neural_inference_calls=0)
        row.update(diagnostics(item['context'],q,release));rows.append(row)
    sums=summarize(rows)
    write_csv(out/'baseline_per_question.csv',rows);write_csv(out/'baseline_summary.csv',sums);write_json(out/'baseline_summary.json',sums)
    write_csv(out/'search_timing.csv',timings)
    receipt=dict(schema_version='fresh-cpu-bm25-diagnostics-v1',created_at_utc=datetime.now(timezone.utc).isoformat(),
        analysis_plan_sha256=sha(out/'analysis_plan.json'),ranking_ids_sha256=ranking_hash,questions=len(questions),contexts=len(rows),
        fit_elapsed_seconds=fit_time,search_elapsed_seconds_total=sum(r['search_elapsed_seconds'] for r in timings),
        python=sys.executable,platform=platform.platform(),bm25_source_sha256=sha(ROOT/'src/retrieval/bm25.py'),
        script_sha256=sha(Path(__file__)),index_manifest_sha256=sha(idx/'index_manifest.json'),chunk_file_sha256=sha(idx/im['chunk_file']),
        questions_sha256=sha(plan['questions_file']),tokenizer_sha256=sha(plan['reference_tokenizer_file']),reference_manifest_sha256=plan['reference_manifest_sha256'],
        jieba_version=importlib.metadata.version('jieba') if _HAS_JIEBA else None,
        fit_includes_legacy_excluded_chunks_for_idf=True,legacy_excluded_from_returned_candidates=True,
        neural_calls=0,llm_calls=0,api_calls=0,paid_calls=0,
        limitation='New sparse baseline scored by page and lexical proxies only. No generated answers or human semantic review. Not a same-day end-to-end neural baseline rerun.')
    write_json(out/'baseline_receipt.json',receipt)
    print(json.dumps([r for r in sums if r['topic']=='ALL' and r['budget_tokens']==6000],ensure_ascii=False),flush=True)


if __name__=='__main__':main()
