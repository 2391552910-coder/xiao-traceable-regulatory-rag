"""Separate PDF-page and whole-TXT reference granularity in retrieval metrics."""
from __future__ import annotations
import csv
import sys
from collections import Counter
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from scripts.replay_cached_retrieval_diagnostics_20261023 import OUT,RUN,load,write_csv,write_json,sha
from src.data.page_reference_release import load_page_reference_release


def main():
    plan=load(RUN/'execution_plan.json');release=load_page_reference_release(plan['reference_dir'],plan['reference_manifest_sha256'])
    counts=Counter((e['role'],'PDF_page' if e['physical_pdf_page_1based'] is not None else 'TXT_source_only') for e in release.evidence.values())
    types={}
    for qid in release.questions:
        laws=[e for e in release.references_for(qid) if e['role']=='regulation']
        qs={e['physical_pdf_page_1based'] is not None for e in laws}
        assert len(qs)==1
        types[qid]='PDF_page' if True in qs else 'TXT_source_only'
    rows=[]
    for method,path in [('cached_hybrid_rerank',OUT/'replay_per_question.csv'),('fresh_bm25_cpu',OUT/'bm25_fresh/baseline_per_question.csv')]:
        raw=list(csv.DictReader(path.open(encoding='utf-8-sig')))
        for strategy in ['merged','dual']:
            for cap in [1000,2000,4000,6000,8000]:
                for granularity in ['PDF_page','TXT_source_only']:
                    group=[r for r in raw if r['strategy']==strategy and int(r['quota'])==10 and int(r['budget_tokens'])==cap and types[r['question_id']]==granularity]
                    rows.append(dict(method=method,strategy=strategy,budget_tokens=cap,candidate_quota=10,
                        law_reference_granularity=granularity,questions=len(group),company_clusters=len({r['stock_code'] for r in group}),
                        reference_location_incidences=sum(int(r['law_reference_pages']) for r in group),
                        selected_location_hits=sum(int(r['law_reference_page_hits']) for r in group),
                        macro_law_reference_location_coverage=float(np.mean([float(r['law_page_coverage']) for r in group])),
                        questions_with_law_reference_location_hit=sum(int(r['law_any_reference_page']) for r in group),
                        fraction_questions_with_law_reference_location_hit=float(np.mean([float(r['law_any_reference_page']) for r in group])),
                        selected_annual_and_law_reference_roles=sum(int(r['both_reference_roles_available']) for r in group),
                        semantic_support_verified=False))
    write_csv(OUT/'law_pdf_vs_txt_granularity_sensitivity.csv',rows)
    write_json(OUT/'law_pdf_vs_txt_at6k.json',[r for r in rows if r['budget_tokens']==6000])
    receipt=dict(total_unique_reference_evidence_records=len(release.evidence),
        unique_pdf_page_bound_reference_records=sum(n for (role,grain),n in counts.items() if grain=='PDF_page'),
        unique_txt_source_only_reference_records=sum(n for (role,grain),n in counts.items() if grain=='TXT_source_only'),
        detail=[dict(role=role,granularity=grain,unique_records=n) for (role,grain),n in sorted(counts.items())],
        source_only_evidence_ids=[eid for eid,e in release.evidence.items() if e['physical_pdf_page_1based'] is None],
        source_only_questions=sum(t=='TXT_source_only' for t in types.values()),pdf_law_questions=sum(t=='PDF_page' for t in types.values()),
        applicability='The previously computed law_page_coverage fields in BOTH cached replay and new BM25 are mixed reference-location proxies; rename them law_reference_location_coverage in prose.',
        warning='BM25 aggregate law-location improvement at6k comes entirely from the coarser TXT source-only references. PDF-only law coverage is zero for both BM25 strategies.',
        input_reference_manifest_sha256=plan['reference_manifest_sha256'],script_sha256=sha(Path(__file__)))
    write_json(OUT/'reference_granularity_counts.json',receipt)
    with (OUT/'检索补实验结果与写作边界.txt').open('a',encoding='utf-8') as stream:
        stream.write('\n九、重要粒度敏感性校正\n123条唯一参考记录中，122条为PDF页绑定（116条年报+6条法规），1条为DOC004 TXT全来源绑定，并被20道内控题复用。\n在6000预算下，PDF法规子集为40题/120个参考定位出现：cached merged0%、cached dual5.833%（7/120）；BM25 merged/dual均0%。TXT来源子集20题：cached两策略均0%；BM25 merged90%（18/20）、dual100%（20/20）。因此BM25混合汇总30%/33.33%的优势全部来自较粗的TXT来源粒度，不能包装为PDF页级或法条级检索改善。\n对应表law_pdf_vs_txt_granularity_sensitivity.csv与reference_granularity_counts.json必须优先用于正文或补充材料。所有cached预算曲线中的law_page_coverage也都采用混合定位代理。\n')
    print(receipt)


if __name__=='__main__':main()
