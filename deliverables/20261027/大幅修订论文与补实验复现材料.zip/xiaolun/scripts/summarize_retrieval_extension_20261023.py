"""Combine executed sparse baseline with archived neural retrieval diagnostics."""
from __future__ import annotations
import csv
import json
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from scripts.replay_cached_retrieval_diagnostics_20261023 import OUT,RUN,load,write_csv,write_json,sha


def main():
    cached=load(OUT/'replay_summary.json');fresh=load(OUT/'bm25_fresh/baseline_summary.json')
    alt=list(csv.DictReader((OUT/'alternate_law_source_summary.csv').open(encoding='utf-8-sig')))
    combined=[]
    for method,rows,date in [('cached_hybrid_rerank',cached,'frozen_contexts_2026-10-20_replayed_2026-10-23'),('fresh_bm25_cpu',fresh,'fresh_sparse_search_2026-10-23')]:
        for r in rows:
            if r['quota']!=10 or r['budget_tokens']!=6000:continue
            item=dict(method=method,strategy=r['strategy'],topic=r['topic'],data_origin=date,
                n_questions=r['n_questions'],company_clusters=r['n_companies'],
                budget_tokens=6000,candidate_quota=10,
                mean_reference_tokens=r['reference_tokens_mean'],mean_selected_chunks=r['selected_chunks_mean'],
                mean_annual_chunks=r['annual_chunks_mean'],mean_law_chunks=r['regulation_chunks_mean'],
                any_annual_and_law_fraction=r['has_both_roles_mean'],annual_reference_location_coverage=r['annual_page_coverage_mean'],
                law_reference_location_coverage=r['law_page_coverage_mean'],
                both_reference_roles_available_fraction=r['both_reference_roles_available_mean'],
                all_reference_locations_covered_fraction=r['all_reference_pages_covered_mean'],
                reference_quote_same_location_12char_coverage=r['reference_quote_12char_shingle_coverage_mean'],
                location_definition='PDF sourceSHA+physicalpage; DOC004TXT uses sourceSHA only',
                semantic_quality_evaluated=False,LLM_calls=0)
            if method=='cached_hybrid_rerank':
                a=next(a for a in alt if a['strategy']==r['strategy'] and a['topic']==r['topic'])
                item['law_quote_source_agnostic_12char_coverage']=a['source_agnostic_law_quote_12char_coverage_mean']
            combined.append(item)
    write_csv(OUT/'baseline_vs_cached_at6k.csv',combined);write_json(OUT/'baseline_vs_cached_at6k.json',combined)
    # Basic invariants on every executed context, rather than tests mirroring ranking code.
    inv=[]
    for fname in [OUT/'replay_per_question.csv',OUT/'bm25_fresh/baseline_per_question.csv']:
        rows=list(csv.DictReader(fname.open(encoding='utf-8-sig')))
        assert all(int(r['reference_tokens'])<=int(r['budget_tokens']) for r in rows)
        assert all(int(r['annual_chunks'])+int(r['regulation_chunks'])==int(r['selected_chunks']) for r in rows)
        assert all(0<=float(r[k])<=1 for r in rows for k in ['annual_page_coverage','law_page_coverage','reference_quote_12char_shingle_coverage'])
        assert len({(r['question_id'],r['strategy'],r['quota'],r['budget_tokens']) for r in rows})==len(rows)
        inv.append(dict(file=str(fname),rows=len(rows),cap_compliant=True,role_counts_reconcile=True,coverage_bounded=True,unique_units=True,sha256=sha(fname)))
    write_json(OUT/'diagnostic_integrity_checks.json',inv)
    report='''检索机制补实验：真实执行结果与可用边界（2026-10-23）

一、已经执行的实验
1. 冻结候选重放：60题、20家公司、3主题；2种检索策略；候选总数2/6/10；参考token上限1000/2000/4000/6000/8000，共1800个上下文。所有检索候选来自2026-10-20封存最终排名，不做神经模型重跑，不生成新回答。5+5双源策略按A1/R1/A2/R2交替；取前2/6/10分别对应1+1/3+3/5+5。统一采用完整chunk、超长跳过、不截断文本策略。
2. 新增BM25真实检索：使用项目原有BM25实现和jieba，k1=1.5、b=0.75，对60条公开问题执行CPU稀疏检索；相同公司/年度和法规候选域；merged前10，dual各源前5交替；5种token上限，共600个上下文。排名ID在读取参考答案之前落盘并记录SHA256。未使用人工参考构造查询，没有新API、付费、GPU或LLM调用。
3. 严格复现与完整性：120/120个原始6000-token上下文逐字节复现；上下文长度和入选chunkID一致；2400个新重放/基线上下文全部不超预算、来源计数一致、无重复实验单位。新图3幅均输出PNG/SVG/PDF，并已视觉检查。

二、语料范围
封存索引19367块。移除旧DOC004的51块、DOC122的66块、DOC343的218块，合计335块，检索可返回19032块，其中年报13038块/39份原件、法规5994块/87份原件。稀疏IDF按完整19367块拟合，随后筛选返回候选，和原HybridRetriever组件一致。60题来自20家公司，各有审计委员会、分红披露、内部控制3主题各20题。参考集合123条原文记录、180个答案点；全部123/123个来源哈希和物理页/文本来源定位都在可检索索引中。

三、指标定义与禁止推断
（1）来源角色存在率：至少一个年报chunk和一个法规chunk；只说明结构。
（2）参考定位覆盖率：按source SHA256+物理PDF页命中，逐题在该来源角色内平均。DOC004是TXT，因此按来源哈希定位，粒度为整个文本。法律覆盖率混合物理页与TXT来源粒度，不能用来宣称语义检索优越。
（3）双参考角色可用率：每题至少一个年报参考定位和至少一个法规参考定位命中。它不是答案点正确率，更不是生成质量。
（4）词面覆盖率：移除空白后，计算参考引文12字符shingle在检索文本中的集合覆盖率。同定位版限同来源/物理页；source-agnostic版允许其他来源/页的法规文本。均不能自动判断语义支持、法规等效或适用性。
（5）参考标签不是穷尽相关性qrels，所以不报告Recall、Precision、MRR、nDCG及其优越性。参考来源/页漏召回也不能判定所检索法规语义无关。

四、6000-token、总候选10的主要结果
封存Hybrid+Reranker merged：平均4945.07 token、8.183年报块+1.183法规块、双角色结构存在68.33%、年报参考定位覆盖79.67%、法规参考定位覆盖0%、双参考角色可用0%。
封存Hybrid+Reranker dual：平均4031.60 token、5年报块+5法规块、双角色结构存在100%、年报参考定位覆盖74.33%、法规参考定位覆盖3.89%、双参考角色可用10%。
新BM25 merged：平均5381.10 token、6.050年报块+3.483法规块、双角色结构存在95%、年报参考定位覆盖73.00%、法规参考定位覆盖30.00%、双参考角色可用28.33%。
新BM25 dual：平均5319.17 token、4.967年报块+4.783法规块、双角色结构存在100%、年报参考定位覆盖69.00%、法规参考定位覆盖33.33%、双参考角色可用33.33%。
不同检索方法返回文本长度不同；相同token上限不等于相同实际上下文长度。没有重新生成这些BM25回答，不能推断新BM25端到端质量。

五、预算和主题差异
Hybrid dual的候选全部可在6000预算内放入，所以8000预算没有继续提升；这是固定最终候选受限的重放，不是扩大检索池的预算实验。1000/2000预算下双角色结构存在率仍为100%，但双参考角色可用率为0；4000为5%，6000和8000为10%。结构保留与参考定位召回之间存在明显差异。
Hybrid dual的年报参考定位覆盖率在审计委员会/分红/内控分别78.0%/67.5%/77.5%；merged分别89.0%/65.0%/85.0%。法规严格定位增益仅发生在分红主题，dual该主题11.67%，其他两主题为0。
对20家公司做10000次聚类bootstrap（种子20261023）：dual-minus-merged年报覆盖差-5.33个百分点，95%区间[-9.17,-1.67]；法规覆盖差+3.89点[1.67,6.11]；双角色结构存在差+31.67点[21.67,41.67]；两角色宏平均定位覆盖差-0.72点[-2.97,1.39]。这些为事后描述性区间，未作多重检验显著性声明。

六、替代来源核查（必须与严格定位结果一起解释）
法规source-agnostic的12字符词面覆盖率：merged为0.587%，dual为11.883%；存在任意词面交集的题数为21/60和40/60。dual有33题虽然严格参考定位未命中，但在其他页或其他法规来源有参考引文词面交集。例如DOC128《上市公司章程指引》第一百三十五条与DOC122物理第9页参考文本有21.48%的12字符shingle交集；OFFICIAL-DOC343物理第2页与该原件第50页参考文本有72.78%交集。这可能反映条文复述、修订决定与正文重复、跨规范共享措辞或不同版本，尚无新增人工等效与适用性核验。不能把严格哈希/页定位遗漏直接写为“法律相关证据完全检索失败”。
入选法规中DOC128累计92块次、DOC120累计50块次、深交所2023年8月上市规则30块次，证明系统确实提供其他规范性材料。它们是否足以支持具体结论仍由现有人工输出评分及后续适用性核验判断。

七、建议写入正文的结论
双源配额显著改变了上下文来源构成，缓解合库排序的角色失衡；其价值不能被等同于检索相关性全面提升。在本数据和预算下，年报严格参考覆盖略降、法规严格参考定位改善有限，且另一来源的相似法条文本增加。补实验揭示结构存在、参考定位和语义支持是三个不同层面。新增BM25是未经端到端生成核验的检索诊断基线，不替代正式人工生成质量实验。
实际调用链prepare_comparison→DualCorpusRetriever.search并未调用DimensionRoutedRetriever；虽配置项dimension_routing=true，正文应描述来源分区、固定配额和交替打包，不应将维度查询路由包装为该批次已执行机制。

八、文件入口
baseline_vs_cached_at6k.csv/json：同scope/配额/预算的4种方法与主题比较。
replay_summary.csv/json与replay_per_question.csv：1800重放单位。
bm25_fresh/baseline_summary.csv/json与baseline_per_question.csv：600个新稀疏基线上下文。
paired_company_bootstrap.csv：company-cluster bootstrap差值与区间。
candidate_vs_packing_audit.csv：最终候选和6000打包后的参考定位差异。
alternate_law_source_*.csv：替代来源词面重合和例子。
retrieval_replay_receipt.json和bm25_fresh/baseline_receipt.json：输入与脚本SHA256、环境和执行记录。
figures/R1-R3：预算、主题、上下文来源分布图。
'''
    (OUT/'检索补实验结果与写作边界.txt').write_text(report,encoding='utf-8')
    print(json.dumps({'combined_rows':len(combined),'integrity':inv},ensure_ascii=False))


if __name__=='__main__':main()
